import sys
from pathlib import Path

# Add project root directory to sys.path so src and app can be imported
root_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root_dir))

from app import app

