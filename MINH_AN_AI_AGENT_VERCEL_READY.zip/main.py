import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from test_runner import run_tests

if __name__ == "__main__":
    file_path = sys.argv[1] if len(sys.argv) > 1 else None
    run_tests(file_path)

