# PHIẾU CHUYỂN DUYỆT CƠ HỘI BÁN HÀNG VƯỢT THẨM QUYỀN
**Mã Phiếu**: `TICKET-OPP-2026-001` | **Mã Hồ sơ**: `OPP-2026-001`
**Kính gửi**: `SALES_MANAGER`
**Khách hàng**: Công ty Cổ phần Công nghệ TechAsia

## 1. THÔNG SỐ ĐỀ XUẤT THƯƠNG MẠI
- **Tổng giá trị niêm yết**: `334,000,000 VNĐ`
- **Tổng giá trị đề xuất sau chiết khấu**: `317,300,000 VNĐ`
- **Mức chiết khấu khách đề nghị**: `2.0%`
- **Mức chiết khấu định mức tiêu chuẩn**: `5.0%`
- **Mức chiết khấu vượt thẩm quyền Sales**: `0.0%`

## 2. NĂNG LỰC CUNG ỨNG & NGÂN SÁCH
- **Tình trạng hàng hóa**: Đủ hàng tồn kho
- **Tiến độ triển khai**: Lead time kỹ thuật: 3 ngày (Khách yêu cầu: 10 ngày)
- **Khả năng chi trả**: Ngân sách khách: 420,000,000 VNĐ

## 3. CĂN CỨ VÀ LÝ DO CHUYỂN CẤP DUYỆT
- 🔴 **Tổng giá trị đơn hàng (317,300,000 VNĐ > 200M) vượt thẩm quyền tự quyết của Sales Rep**

## 4. ĐỀ XUẤT CỦA BỘ PHẬN KINH DOANH
Đề xuất SALES_MANAGER xem xét phê duyệt chính sách thương mại để hỗ trợ chốt hợp đồng lớn với khách hàng Công ty Cổ phần Công nghệ TechAsia.

---
**Ý KIẾN CỦA CẤP PHÊ DUYỆT:**
[  ] ĐỒNG Ý PHÊ DUYỆT THEO ĐỀ XUẤT
[  ] YÊU CẦU ĐÀM PHÁN LẠI VỚI KHÁCH HÀNG (Ghi chú lý do)
[  ] TỪ CHỐI

Chữ ký / Xác thực điện tử: ....................................... Ngày: ...../...../2026