# PHIẾU CHUYỂN DUYỆT CƠ HỘI BÁN HÀNG VƯỢT THẨM QUYỀN
**Mã Phiếu**: `TICKET-OPP-2026-002` | **Mã Hồ sơ**: `OPP-2026-002`
**Kính gửi**: `SALES_MANAGER`
**Khách hàng**: Tập đoàn Đầu tư An Thịnh

## 1. THÔNG SỐ ĐỀ XUẤT THƯƠNG MẠI
- **Tổng giá trị niêm yết**: `489,000,000 VNĐ`
- **Tổng giá trị đề xuất sau chiết khấu**: `449,880,000 VNĐ`
- **Mức chiết khấu khách đề nghị**: `8.0%`
- **Mức chiết khấu định mức tiêu chuẩn**: `7.0%`
- **Mức chiết khấu vượt thẩm quyền Sales**: `1.0%`

## 2. NĂNG LỰC CUNG ỨNG & NGÂN SÁCH
- **Tình trạng hàng hóa**: Đủ hàng tồn kho
- **Tiến độ triển khai**: Lead time kỹ thuật: 4 ngày (Khách yêu cầu: 5 ngày)
- **Khả năng chi trả**: Ngân sách khách: 320,000,000 VNĐ

## 3. CĂN CỨ VÀ LÝ DO CHUYỂN CẤP DUYỆT
- 🔴 **Tổng giá trị đơn hàng (449,880,000 VNĐ > 200M) vượt thẩm quyền tự quyết của Sales Rep**
- 🔴 **Ngân sách khách hàng thiếu hụt 28.9% so với giá trị đề xuất sau chiết khấu**

## 4. ĐỀ XUẤT CỦA BỘ PHẬN KINH DOANH
Đề xuất SALES_MANAGER xem xét phê duyệt chính sách thương mại để hỗ trợ chốt hợp đồng lớn với khách hàng Tập đoàn Đầu tư An Thịnh.

---
**Ý KIẾN CỦA CẤP PHÊ DUYỆT:**
[  ] ĐỒNG Ý PHÊ DUYỆT THEO ĐỀ XUẤT
[  ] YÊU CẦU ĐÀM PHÁN LẠI VỚI KHÁCH HÀNG (Ghi chú lý do)
[  ] TỪ CHỐI

Chữ ký / Xác thực điện tử: ....................................... Ngày: ...../...../2026