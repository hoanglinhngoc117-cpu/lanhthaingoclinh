﻿# PHIẾU CHUYỂN DUYỆT CƠ HỘI BÁN HÀNG VƯỢT THẨM QUYỀN
**Mã Phiếu**: TICKET-OPP-2026-003 | **Cấp duyệt**: $(@{gross_total=12468000000; net_total=11470560000; effective_discount=8; extra_discount=0; policy_discount=8; required_level=BOD; escalation_reasons=System.Object[]}.required_level)
**Khách hàng**: Công ty TNHH Giải pháp Phần mềm VinaSoft
**Giá trị đơn hàng (Net)**: 11,470,560,000 VNĐ (Chiết khấu: 8.0%)
**Căn cứ chuyển duyệt**:
- 🔴 Tổng giá trị đơn hàng (11,470,560,000 VNĐ >= 500M) cần Ban Giám đốc phê duyệt
- 🔴 Tồn kho không đủ đáp ứng, cần điều phối nhập hàng đặc biệt
