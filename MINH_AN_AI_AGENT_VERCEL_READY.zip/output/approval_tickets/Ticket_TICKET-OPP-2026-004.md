# PHIẾU CHUYỂN DUYỆT CƠ HỘI BÁN HÀNG VƯỢT THẨM QUYỀN
**Mã Phiếu**: `TICKET-OPP-2026-004` | **Mã Hồ sơ**: `OPP-2026-004`
**Kính gửi**: `BOD`
**Khách hàng**: Ngân hàng TMCP Phương Nam (Chi nhánh Miền Trung)

## 1. THÔNG SỐ ĐỀ XUẤT THƯƠNG MẠI
- **Tổng giá trị niêm yết**: `1,125,000,000 VNĐ`
- **Tổng giá trị đề xuất sau chiết khấu**: `978,750,000 VNĐ`
- **Mức chiết khấu khách đề nghị**: `12.0%`
- **Mức chiết khấu định mức tiêu chuẩn**: `13.0%`
- **Mức chiết khấu vượt thẩm quyền Sales**: `0.0%`

## 2. NĂNG LỰC CUNG ỨNG & NGÂN SÁCH
- **Tình trạng hàng hóa**: THIẾU TỒN KHO - Cần nhập khẩn
- **Tiến độ triển khai**: Lead time kỹ thuật: 21 ngày (Khách yêu cầu: 7 ngày)
- **Khả năng chi trả**: Ngân sách khách: 1,100,000,000 VNĐ

## 3. CĂN CỨ VÀ LÝ DO CHUYỂN CẤP DUYỆT
- 🔴 **Mức chiết khấu đề nghị (13.0%, vượt định mức 0.0%) thuộc thẩm quyền phê duyệt của Ban Giám đốc**
- 🔴 **Tổng giá trị đơn hàng (978,750,000 VNĐ >= 500M) cần Ban Giám đốc phê duyệt**
- 🔴 **Tồn kho hiện tại không đủ đáp ứng toàn bộ số lượng yêu cầu, cần ý kiến Trưởng phòng & Vận hành**
- 🔴 **RỦI RO TIẾN ĐỘ: Khách hàng yêu cầu giao trong 7 ngày, nhưng thời gian tối thiểu để chuẩn bị và triển khai là 21 ngày (do một số mặt hàng hết kho cần nhập thêm).**

## 4. ĐỀ XUẤT CỦA BỘ PHẬN KINH DOANH
Đề xuất BOD xem xét phê duyệt chính sách thương mại để hỗ trợ chốt hợp đồng lớn với khách hàng Ngân hàng TMCP Phương Nam (Chi nhánh Miền Trung).

---
**Ý KIẾN CỦA CẤP PHÊ DUYỆT:**
[  ] ĐỒNG Ý PHÊ DUYỆT THEO ĐỀ XUẤT
[  ] YÊU CẦU ĐÀM PHÁN LẠI VỚI KHÁCH HÀNG (Ghi chú lý do)
[  ] TỪ CHỐI

Chữ ký / Xác thực điện tử: ....................................... Ngày: ...../...../2026