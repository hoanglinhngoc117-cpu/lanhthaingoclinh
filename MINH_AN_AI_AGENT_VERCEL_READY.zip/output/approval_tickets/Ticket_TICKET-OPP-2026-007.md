# PHIẾU CHUYỂN DUYỆT CƠ HỘI BÁN HÀNG VƯỢT THẨM QUYỀN
**Mã Phiếu**: `TICKET-OPP-2026-007` | **Mã Hồ sơ**: `OPP-2026-007`
**Kính gửi**: `BOD`
**Khách hàng**: Công ty CP Dược phẩm Khang An

## 1. THÔNG SỐ ĐỀ XUẤT THƯƠNG MẠI
- **Tổng giá trị niêm yết**: `1,000,000,000 VNĐ`
- **Tổng giá trị đề xuất sau chiết khấu**: `920,000,000 VNĐ`
- **Mức chiết khấu khách đề nghị**: `3.0%`
- **Mức chiết khấu định mức tiêu chuẩn**: `8.0%`
- **Mức chiết khấu vượt thẩm quyền Sales**: `0.0%`

## 2. NĂNG LỰC CUNG ỨNG & NGÂN SÁCH
- **Tình trạng hàng hóa**: Đủ hàng tồn kho
- **Tiến độ triển khai**: Lead time kỹ thuật: 3 ngày (Khách yêu cầu: 5 ngày)
- **Khả năng chi trả**: Ngân sách khách: 1,000,000,000 VNĐ

## 3. CĂN CỨ VÀ LÝ DO CHUYỂN CẤP DUYỆT
- 🔴 **Tổng giá trị đơn hàng (920,000,000 VNĐ >= 500M) cần Ban Giám đốc phê duyệt**

## 4. ĐỀ XUẤT CỦA BỘ PHẬN KINH DOANH
Đề xuất BOD xem xét phê duyệt chính sách thương mại để hỗ trợ chốt hợp đồng lớn với khách hàng Công ty CP Dược phẩm Khang An.

---
**Ý KIẾN CỦA CẤP PHÊ DUYỆT:**
[  ] ĐỒNG Ý PHÊ DUYỆT THEO ĐỀ XUẤT
[  ] YÊU CẦU ĐÀM PHÁN LẠI VỚI KHÁCH HÀNG (Ghi chú lý do)
[  ] TỪ CHỐI

Chữ ký / Xác thực điện tử: ....................................... Ngày: ...../...../2026