# HỒ SƠ CƠ HỘI BÁN HÀNG B2B - OPP-2026-001
**Mã yêu cầu gốc**: `REQ-2026-001` | **Ngày xử lý**: 2026-11-11
**Khách hàng**: Công ty Cổ phần Công nghệ TechAsia (Hạng: `STANDARD`)
**Đại diện liên hệ**: Nguyễn Hoàng Nam - Trưởng phòng IT | **Email**: nam.nh@techasia.vn | **Điện thoại**: 0912345678

## 1. TÌNH TRẠNG VÀ PHÂN LOẠI CƠ HỘI
- **Trạng thái xử lý**: `PENDING_APPROVAL`
- **Cấp thẩm quyền quyết định**: `SALES_MANAGER`
- **Căn cứ quyết định**: Vượt thẩm quyền tự quyết của Sales Rep (Tổng giá trị đơn hàng (317,300,000 VNĐ > 200M) vượt thẩm quyền tự quyết của Sales Rep). Chuyển SALES_MANAGER duyệt.
- **Bước xử lý tiếp theo**: Lập Phiếu chuyển duyệt trình SALES_MANAGER xem xét; đồng thời gửi thư báo tiến nhận hồ sơ cho khách hàng.

## 2. KẾT QUẢ ĐỐI CHIẾU HẠNG MỤC & TỒN KHO
| SKU | Tên Hạng Mục | SL Yêu Cầu | Đơn Giá (VNĐ) | Thành Tiền (VNĐ) | Tồn Kho | Trạng Thái Kho |
| --- | --- | ---: | ---: | ---: | ---: | :---: |
| `SRV-DELL-R750` | Máy chủ Dell PowerEdge R750 (2x Intel Xeon Silver 4314, 64GB RAM, 2x 960GB SSD) | 2 | 125,000,000 | 250,000,000 | 8 | ✅ Sẵn sàng |
| `SW-CISCO-C9200L` | Thiết bị chuyển mạch Cisco Catalyst 9200L (24 ports PoE+, 4x 10G uplink) | 2 | 34,500,000 | 69,000,000 | 15 | ✅ Sẵn sàng |
| `SVC-DEPLOY-BASIC` | Dịch vụ lắp đặt, cấu hình hệ thống mạng & máy chủ cơ bản (On-site 3 ngày) | 1 | 15,000,000 | 15,000,000 | 999 | ✅ Sẵn sàng |

## 3. PHÂN TÍCH TÀI CHÍNH & CHÍNH SÁCH THƯƠNG MẠI
- **Tổng giá trị niêm yết (Gross Total)**: `334,000,000 VNĐ`
- **Chiết khấu áp dụng**: `5.0%`
- **Giá trị đề xuất thanh toán (Net Total)**: `317,300,000 VNĐ`
- **Ngân sách công bố của khách hàng**: `420,000,000 VNĐ`

## 4. ĐÁNH GIÁ NĂNG LỰC ĐÁP ỨNG THỜI GIAN
- **Thời hạn khách yêu cầu**: `10 ngày`
- **Thời gian đáp ứng tối thiểu của Minh An**: `3 ngày`
- **Kết luận tiến độ**: ✅ Đáp ứng tốt

## 5. LÝ DO CHUYỂN DUYỆT (ESCALATION REASONS)
- ⚠️ Tổng giá trị đơn hàng (317,300,000 VNĐ > 200M) vượt thẩm quyền tự quyết của Sales Rep

---
*Hồ sơ được tạo tự động bởi AI Agent Minh An - Đã lưu vết Audit Trail đầy đủ.*