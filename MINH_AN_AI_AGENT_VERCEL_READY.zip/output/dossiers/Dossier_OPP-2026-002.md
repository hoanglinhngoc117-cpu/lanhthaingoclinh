# HỒ SƠ CƠ HỘI BÁN HÀNG B2B - OPP-2026-002
**Mã yêu cầu gốc**: `REQ-2026-002` | **Ngày xử lý**: 2026-11-11
**Khách hàng**: Tập đoàn Đầu tư An Thịnh (Hạng: `SILVER`)
**Đại diện liên hệ**: Trần Thị Lan - Ban Mua hàng | **Email**: lan.tran@anthinhgroup.com | **Điện thoại**: 0988776655

## 1. TÌNH TRẠNG VÀ PHÂN LOẠI CƠ HỘI
- **Trạng thái xử lý**: `PENDING_APPROVAL`
- **Cấp thẩm quyền quyết định**: `SALES_MANAGER`
- **Căn cứ quyết định**: Vượt thẩm quyền tự quyết của Sales Rep (Tổng giá trị đơn hàng (449,880,000 VNĐ > 200M) vượt thẩm quyền tự quyết của Sales Rep; Ngân sách khách hàng thiếu hụt 28.9% so với giá trị đề xuất sau chiết khấu). Chuyển SALES_MANAGER duyệt.
- **Bước xử lý tiếp theo**: Lập Phiếu chuyển duyệt trình SALES_MANAGER xem xét; đồng thời gửi thư báo tiến nhận hồ sơ cho khách hàng.

## 2. KẾT QUẢ ĐỐI CHIẾU HẠNG MỤC & TỒN KHO
| SKU | Tên Hạng Mục | SL Yêu Cầu | Đơn Giá (VNĐ) | Thành Tiền (VNĐ) | Tồn Kho | Trạng Thái Kho |
| --- | --- | ---: | ---: | ---: | ---: | :---: |
| `SRV-HPE-DL380` | Máy chủ HPE ProLiant DL380 Gen10 (Intel Xeon 4210R, 32GB RAM, 1.2TB SAS) | 3 | 98,000,000 | 294,000,000 | 5 | ✅ Sẵn sàng |
| `SAN-SYNOLOGY-RS2423` | Thiết bị lưu trữ NAS Synology RackStation RS2423+ (12 Bays, chưa kèm ổ) | 3 | 65,000,000 | 195,000,000 | 4 | ✅ Sẵn sàng |

## 3. PHÂN TÍCH TÀI CHÍNH & CHÍNH SÁCH THƯƠNG MẠI
- **Tổng giá trị niêm yết (Gross Total)**: `489,000,000 VNĐ`
- **Chiết khấu áp dụng**: `8.0%`
- **Giá trị đề xuất thanh toán (Net Total)**: `449,880,000 VNĐ`
- **Ngân sách công bố của khách hàng**: `320,000,000 VNĐ`

## 4. ĐÁNH GIÁ NĂNG LỰC ĐÁP ỨNG THỜI GIAN
- **Thời hạn khách yêu cầu**: `5 ngày`
- **Thời gian đáp ứng tối thiểu của Minh An**: `4 ngày`
- **Kết luận tiến độ**: ✅ Đáp ứng tốt

## 5. LÝ DO CHUYỂN DUYỆT (ESCALATION REASONS)
- ⚠️ Tổng giá trị đơn hàng (449,880,000 VNĐ > 200M) vượt thẩm quyền tự quyết của Sales Rep
- ⚠️ Ngân sách khách hàng thiếu hụt 28.9% so với giá trị đề xuất sau chiết khấu

---
*Hồ sơ được tạo tự động bởi AI Agent Minh An - Đã lưu vết Audit Trail đầy đủ.*