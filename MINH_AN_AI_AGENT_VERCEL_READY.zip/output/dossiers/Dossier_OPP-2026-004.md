# HỒ SƠ CƠ HỘI BÁN HÀNG B2B - OPP-2026-004
**Mã yêu cầu gốc**: `REQ-2026-004` | **Ngày xử lý**: 2026-11-11
**Khách hàng**: Ngân hàng TMCP Phương Nam (Chi nhánh Miền Trung) (Hạng: `GOLD`)
**Đại diện liên hệ**: Vũ Mạnh Hùng - Phó Giám đốc Trung tâm Vận hành | **Email**: hungvm@phuongnambank.vn | **Điện thoại**: 0903112233

## 1. TÌNH TRẠNG VÀ PHÂN LOẠI CƠ HỘI
- **Trạng thái xử lý**: `PENDING_APPROVAL`
- **Cấp thẩm quyền quyết định**: `BOD`
- **Căn cứ quyết định**: Vượt thẩm quyền tự quyết của Sales Rep (Mức chiết khấu đề nghị (13.0%, vượt định mức 0.0%) thuộc thẩm quyền phê duyệt của Ban Giám đốc; Tổng giá trị đơn hàng (978,750,000 VNĐ >= 500M) cần Ban Giám đốc phê duyệt; Tồn kho hiện tại không đủ đáp ứng toàn bộ số lượng yêu cầu, cần ý kiến Trưởng phòng & Vận hành; RỦI RO TIẾN ĐỘ: Khách hàng yêu cầu giao trong 7 ngày, nhưng thời gian tối thiểu để chuẩn bị và triển khai là 21 ngày (do một số mặt hàng hết kho cần nhập thêm).). Chuyển BOD duyệt.
- **Bước xử lý tiếp theo**: Lập Phiếu chuyển duyệt trình BOD xem xét; đồng thời gửi thư báo tiến nhận hồ sơ cho khách hàng.

## 2. KẾT QUẢ ĐỐI CHIẾU HẠNG MỤC & TỒN KHO
| SKU | Tên Hạng Mục | SL Yêu Cầu | Đơn Giá (VNĐ) | Thành Tiền (VNĐ) | Tồn Kho | Trạng Thái Kho |
| --- | --- | ---: | ---: | ---: | ---: | :---: |
| `SRV-DELL-R750` | Máy chủ Dell PowerEdge R750 (2x Intel Xeon Silver 4314, 64GB RAM, 2x 960GB SSD) | 9 | 125,000,000 | 1,125,000,000 | 8 | ⚠️ Thiếu kho |

## 3. PHÂN TÍCH TÀI CHÍNH & CHÍNH SÁCH THƯƠNG MẠI
- **Tổng giá trị niêm yết (Gross Total)**: `1,125,000,000 VNĐ`
- **Chiết khấu áp dụng**: `13.0%`
- **Giá trị đề xuất thanh toán (Net Total)**: `978,750,000 VNĐ`
- **Ngân sách công bố của khách hàng**: `1,100,000,000 VNĐ`

## 4. ĐÁNH GIÁ NĂNG LỰC ĐÁP ỨNG THỜI GIAN
- **Thời hạn khách yêu cầu**: `7 ngày`
- **Thời gian đáp ứng tối thiểu của Minh An**: `21 ngày`
- **Kết luận tiến độ**: ❌ Cảnh báo rủi ro tiến độ

## 5. LÝ DO CHUYỂN DUYỆT (ESCALATION REASONS)
- ⚠️ Mức chiết khấu đề nghị (13.0%, vượt định mức 0.0%) thuộc thẩm quyền phê duyệt của Ban Giám đốc
- ⚠️ Tổng giá trị đơn hàng (978,750,000 VNĐ >= 500M) cần Ban Giám đốc phê duyệt
- ⚠️ Tồn kho hiện tại không đủ đáp ứng toàn bộ số lượng yêu cầu, cần ý kiến Trưởng phòng & Vận hành
- ⚠️ RỦI RO TIẾN ĐỘ: Khách hàng yêu cầu giao trong 7 ngày, nhưng thời gian tối thiểu để chuẩn bị và triển khai là 21 ngày (do một số mặt hàng hết kho cần nhập thêm).

---
*Hồ sơ được tạo tự động bởi AI Agent Minh An - Đã lưu vết Audit Trail đầy đủ.*