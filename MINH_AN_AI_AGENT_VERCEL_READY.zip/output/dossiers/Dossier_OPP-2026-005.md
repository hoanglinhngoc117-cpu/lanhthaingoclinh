# HỒ SƠ CƠ HỘI BÁN HÀNG B2B - OPP-2026-005
**Mã yêu cầu gốc**: `REQ-2026-005` | **Ngày xử lý**: 2026-11-11
**Khách hàng**: Bệnh viện Đa khoa Quốc tế Phúc An (Hạng: `STANDARD`)
**Đại diện liên hệ**: Lê Thị Mai - Phòng CNTT | **Email**: maile@phucanhospital.vn | **Điện thoại**: 0934567890

## 1. TÌNH TRẠNG VÀ PHÂN LOẠI CƠ HỘI
- **Trạng thái xử lý**: `CANNOT_FULFILL`
- **Cấp thẩm quyền quyết định**: `SALES_MANAGER`
- **Căn cứ quyết định**: Thời hạn khách hàng yêu cầu (1 ngày) không thể đáp ứng kỹ thuật (tối thiểu 3 ngày).
- **Bước xử lý tiếp theo**: Gửi email đề xuất điều chỉnh thời gian giao hàng hoặc thay thế bằng phương án khả thi; chuyên viên gọi điện tư vấn.

## 2. KẾT QUẢ ĐỐI CHIẾU HẠNG MỤC & TỒN KHO
| SKU | Tên Hạng Mục | SL Yêu Cầu | Đơn Giá (VNĐ) | Thành Tiền (VNĐ) | Tồn Kho | Trạng Thái Kho |
| --- | --- | ---: | ---: | ---: | ---: | :---: |
| `SRV-HPE-DL380` | Máy chủ HPE ProLiant DL380 Gen10 (Intel Xeon 4210R, 32GB RAM, 1.2TB SAS) | 1 | 98,000,000 | 98,000,000 | 5 | ✅ Sẵn sàng |
| `SVC-MAINTAIN-1Y` | Gói bảo trì định kỳ hệ thống CNTT Doanh nghiệp 1 năm (SLA 4 giờ) | 1 | 36,000,000 | 36,000,000 | 999 | ✅ Sẵn sàng |

## 3. PHÂN TÍCH TÀI CHÍNH & CHÍNH SÁCH THƯƠNG MẠI
- **Tổng giá trị niêm yết (Gross Total)**: `134,000,000 VNĐ`
- **Chiết khấu áp dụng**: `2.5%`
- **Giá trị đề xuất thanh toán (Net Total)**: `130,650,000 VNĐ`
- **Ngân sách công bố của khách hàng**: `140,000,000 VNĐ`

## 4. ĐÁNH GIÁ NĂNG LỰC ĐÁP ỨNG THỜI GIAN
- **Thời hạn khách yêu cầu**: `1 ngày`
- **Thời gian đáp ứng tối thiểu của Minh An**: `3 ngày`
- **Kết luận tiến độ**: ❌ Cảnh báo rủi ro tiến độ

## 5. LÝ DO CHUYỂN DUYỆT (ESCALATION REASONS)
- ⚠️ RỦI RO TIẾN ĐỘ: Khách hàng yêu cầu giao trong 1 ngày, nhưng thời gian tối thiểu để chuẩn bị và triển khai là 3 ngày (theo quy trình kỹ thuật chuẩn).

---
*Hồ sơ được tạo tự động bởi AI Agent Minh An - Đã lưu vết Audit Trail đầy đủ.*