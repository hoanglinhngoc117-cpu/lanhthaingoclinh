# HỒ SƠ CƠ HỘI BÁN HÀNG B2B - OPP-2026-006
**Mã yêu cầu gốc**: `REQ-2026-006` | **Ngày xử lý**: 2026-11-11
**Khách hàng**: Công ty TNHH Truyền thông Sao Mai (Hạng: `STANDARD`)
**Đại diện liên hệ**: Chưa rõ | **Email**: contact@saomaimedia.vn | **Điện thoại**: Chưa rõ

## 1. TÌNH TRẠNG VÀ PHÂN LOẠI CƠ HỘI
- **Trạng thái xử lý**: `NEEDS_INFO`
- **Cấp thẩm quyền quyết định**: `SALES_REP`
- **Căn cứ quyết định**: Thiếu thông tin bắt buộc để định giá (Số lượng cho hạng mục 'Thiết bị CNTT chưa rõ chủng loại / model', Tổng ngân sách dự kiến của khách hàng, Thời hạn triển khai / bàn giao mong muốn, Người đại diện liên hệ / Người có thẩm quyền phê duyệt)
- **Bước xử lý tiếp theo**: Gửi email phản hồi đề nghị khách hàng cung cấp bổ sung chi tiết số lượng và quy cách kỹ thuật.

## 2. KẾT QUẢ ĐỐI CHIẾU HẠNG MỤC & TỒN KHO
| SKU | Tên Hạng Mục | SL Yêu Cầu | Đơn Giá (VNĐ) | Thành Tiền (VNĐ) | Tồn Kho | Trạng Thái Kho |
| --- | --- | ---: | ---: | ---: | ---: | :---: |
| `None` | Thiết bị CNTT chưa rõ chủng loại / model | N/A | 0 | 0 | 0 | ⚠️ Thiếu kho |

## 3. PHÂN TÍCH TÀI CHÍNH & CHÍNH SÁCH THƯƠNG MẠI
- **Tổng giá trị niêm yết (Gross Total)**: `0 VNĐ`
- **Chiết khấu áp dụng**: `0.0%`
- **Giá trị đề xuất thanh toán (Net Total)**: `0 VNĐ`
- **Ngân sách công bố của khách hàng**: `Không công bố`

## 4. ĐÁNH GIÁ NĂNG LỰC ĐÁP ỨNG THỜI GIAN
- **Thời hạn khách yêu cầu**: `Không nêu`
- **Thời gian đáp ứng tối thiểu của Minh An**: `0 ngày`
- **Kết luận tiến độ**: ✅ Đáp ứng tốt

## 6. THÔNG TIN CÒN THIẾU CẦN KHÁCH HÀNG BỔ SUNG
- ❓ Số lượng cho hạng mục 'Thiết bị CNTT chưa rõ chủng loại / model'
- ❓ Tổng ngân sách dự kiến của khách hàng
- ❓ Thời hạn triển khai / bàn giao mong muốn
- ❓ Người đại diện liên hệ / Người có thẩm quyền phê duyệt

---
*Hồ sơ được tạo tự động bởi AI Agent Minh An - Đã lưu vết Audit Trail đầy đủ.*