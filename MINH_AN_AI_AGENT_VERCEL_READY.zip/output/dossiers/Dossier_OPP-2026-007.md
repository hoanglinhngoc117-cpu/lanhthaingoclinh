# HỒ SƠ CƠ HỘI BÁN HÀNG B2B - OPP-2026-007
**Mã yêu cầu gốc**: `REQ-2026-007` | **Ngày xử lý**: 2026-11-11
**Khách hàng**: Công ty CP Dược phẩm Khang An (Hạng: `STANDARD`)
**Đại diện liên hệ**: Hoàng Văn Tuấn - Giám đốc Mua hàng | **Email**: tuanhv@khanganpharma.com | **Điện thoại**: 0945678123

## 1. TÌNH TRẠNG VÀ PHÂN LOẠI CƠ HỘI
- **Trạng thái xử lý**: `PENDING_APPROVAL`
- **Cấp thẩm quyền quyết định**: `BOD`
- **Căn cứ quyết định**: Vượt thẩm quyền tự quyết của Sales Rep (Tổng giá trị đơn hàng (920,000,000 VNĐ >= 500M) cần Ban Giám đốc phê duyệt). Chuyển BOD duyệt.
- **Bước xử lý tiếp theo**: Lập Phiếu chuyển duyệt trình BOD xem xét; đồng thời gửi thư báo tiến nhận hồ sơ cho khách hàng.

## 2. KẾT QUẢ ĐỐI CHIẾU HẠNG MỤC & TỒN KHO
| SKU | Tên Hạng Mục | SL Yêu Cầu | Đơn Giá (VNĐ) | Thành Tiền (VNĐ) | Tồn Kho | Trạng Thái Kho |
| --- | --- | ---: | ---: | ---: | ---: | :---: |
| `SRV-DELL-R750` | Máy chủ Dell PowerEdge R750 (2x Intel Xeon Silver 4314, 64GB RAM, 2x 960GB SSD) | 8 | 125,000,000 | 1,000,000,000 | 8 | ✅ Sẵn sàng |

## 3. PHÂN TÍCH TÀI CHÍNH & CHÍNH SÁCH THƯƠNG MẠI
- **Tổng giá trị niêm yết (Gross Total)**: `1,000,000,000 VNĐ`
- **Chiết khấu áp dụng**: `8.0%`
- **Giá trị đề xuất thanh toán (Net Total)**: `920,000,000 VNĐ`
- **Ngân sách công bố của khách hàng**: `1,000,000,000 VNĐ`

## 4. ĐÁNH GIÁ NĂNG LỰC ĐÁP ỨNG THỜI GIAN
- **Thời hạn khách yêu cầu**: `5 ngày`
- **Thời gian đáp ứng tối thiểu của Minh An**: `3 ngày`
- **Kết luận tiến độ**: ✅ Đáp ứng tốt

## 5. LÝ DO CHUYỂN DUYỆT (ESCALATION REASONS)
- ⚠️ Tổng giá trị đơn hàng (920,000,000 VNĐ >= 500M) cần Ban Giám đốc phê duyệt

---
*Hồ sơ được tạo tự động bởi AI Agent Minh An - Đã lưu vết Audit Trail đầy đủ.*