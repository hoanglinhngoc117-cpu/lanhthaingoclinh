# HỒ SƠ CƠ HỘI BÁN HÀNG B2B - OPP-2026-008
**Mã yêu cầu gốc**: `REQ-2026-008` | **Ngày xử lý**: 2026-11-11
**Khách hàng**: Công ty Cổ phần Vận tải SmartLogistics (Hạng: `STANDARD`)
**Đại diện liên hệ**: Ngô Quốc Bảo - Trưởng nhóm Hạ tầng | **Email**: baonq@smartlog.vn | **Điện thoại**: 0977112233

## 1. TÌNH TRẠNG VÀ PHÂN LOẠI CƠ HỘI
- **Trạng thái xử lý**: `CAN_PROCEED`
- **Cấp thẩm quyền quyết định**: `SALES_REP`
- **Căn cứ quyết định**: Dữ liệu đầy đủ; Hàng hóa có sẵn; Chiết khấu và giá trị đơn hàng trong hạn mức tự quyết của Nhân viên Kinh doanh.
- **Bước xử lý tiếp theo**: Gửi Báo giá chính thức và Hợp đồng mẫu cho khách hàng; phân công Sales Rep theo dõi chốt đơn.

## 2. KẾT QUẢ ĐỐI CHIẾU HẠNG MỤC & TỒN KHO
| SKU | Tên Hạng Mục | SL Yêu Cầu | Đơn Giá (VNĐ) | Thành Tiền (VNĐ) | Tồn Kho | Trạng Thái Kho |
| --- | --- | ---: | ---: | ---: | ---: | :---: |
| `SW-CISCO-C9200L` | Thiết bị chuyển mạch Cisco Catalyst 9200L (24 ports PoE+, 4x 10G uplink) | 1 | 34,500,000 | 34,500,000 | 15 | ✅ Sẵn sàng |
| `AP-ARUBA-AP505` | Bộ phát WiFi chuyên dụng Aruba Instant On AP505 (Wi-Fi 6, 2x2 MIMO) | 1 | 5,800,000 | 5,800,000 | 40 | ✅ Sẵn sàng |
| `SVC-DEPLOY-BASIC` | Dịch vụ lắp đặt, cấu hình hệ thống mạng & máy chủ cơ bản (On-site 3 ngày) | 1 | 15,000,000 | 15,000,000 | 999 | ✅ Sẵn sàng |

## 3. PHÂN TÍCH TÀI CHÍNH & CHÍNH SÁCH THƯƠNG MẠI
- **Tổng giá trị niêm yết (Gross Total)**: `55,300,000 VNĐ`
- **Chiết khấu áp dụng**: `0.0%`
- **Giá trị đề xuất thanh toán (Net Total)**: `55,300,000 VNĐ`
- **Ngân sách công bố của khách hàng**: `70,000,000 VNĐ`

## 4. ĐÁNH GIÁ NĂNG LỰC ĐÁP ỨNG THỜI GIAN
- **Thời hạn khách yêu cầu**: `5 ngày`
- **Thời gian đáp ứng tối thiểu của Minh An**: `2 ngày`
- **Kết luận tiến độ**: ✅ Đáp ứng tốt

---
*Hồ sơ được tạo tự động bởi AI Agent Minh An - Đã lưu vết Audit Trail đầy đủ.*