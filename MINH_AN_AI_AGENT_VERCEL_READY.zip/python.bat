@echo off
"C:\Users\Admin\AppData\Local\Programs\Python\Python311\python.exe" %*

