# ==============================================================================
# HỆ THỐNG AI AGENT XỬ LÝ CƠ HỘI BÁN HÀNG B2B - CÔNG TY MINH AN
# File thực thi trực tiếp trên PowerShell (Native Windows Runner)
# ==============================================================================

param(
    [string]$DataFilePath = "data\sample_requests.json"
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$BaseDir = $PSScriptRoot
$DataDir = Join-Path $BaseDir "data"
$OutputDir = Join-Path $BaseDir "output"
$DossiersDir = Join-Path $OutputDir "dossiers"
$DraftEmailsDir = Join-Path $OutputDir "draft_emails"
$ApprovalTicketsDir = Join-Path $OutputDir "approval_tickets"
$LogsDir = Join-Path $OutputDir "logs"

foreach ($dir in @($OutputDir, $DossiersDir, $DraftEmailsDir, $ApprovalTicketsDir, $LogsDir)) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
}

$AuditLogFile = Join-Path $LogsDir "execution_audit.log"
"" | Out-File -FilePath $AuditLogFile -Encoding UTF8

function Log-Audit {
    param(
        [string]$RequestId,
        [string]$EventType,
        [string]$StepName,
        [string]$Message,
        [string]$Details = ""
    )
    $ts = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss.fff")
    $logLine = "[$ts] [$RequestId] EVENT=$EventType | STEP=$StepName | $Message | $Details"
    Add-Content -Path $AuditLogFile -Value $logLine -Encoding UTF8
}

Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "   AI301 AI AGENT - DỰ ÁN 01: XỬ LÝ CƠ HỘI BÁN HÀNG B2B (CÔNG TY MINH AN)     " -ForegroundColor Yellow
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "Dang doc du lieu tu: $DataFilePath`n" -ForegroundColor Gray

# 1. Load Knowledge Base
$CatalogPath = Join-Path $DataDir "products_catalog.json"
$DiscountPolicyPath = Join-Path $DataDir "discount_policy.json"
$ApprovalMatrixPath = Join-Path $DataDir "approval_matrix.json"

$Catalog = Get-Content $CatalogPath -Raw -Encoding UTF8 | ConvertFrom-Json
$DiscountPolicy = Get-Content $DiscountPolicyPath -Raw -Encoding UTF8 | ConvertFrom-Json
$ApprovalMatrix = Get-Content $ApprovalMatrixPath -Raw -Encoding UTF8 | ConvertFrom-Json

$ResolvedDataPath = if (Test-Path $DataFilePath) { $DataFilePath } else { Join-Path $BaseDir $DataFilePath }
if (-not (Test-Path $ResolvedDataPath)) {
    Write-Host "[ERROR] Khong tim thay file: $ResolvedDataPath" -ForegroundColor Red
    exit 1
}

$Requests = Get-Content $ResolvedDataPath -Raw -Encoding UTF8 | ConvertFrom-Json

# Tool 1: Extraction & Normalization
function Invoke-ExtractionTool {
    param($Request, $CatalogList)
    $text = $Request.raw_request_text
    $items = @()
    $missingFields = @()

    $kwMap = @(
        @{ SKU="SRV-DELL-R750"; KW=@("dell poweredge r750", "dell r750", "poweredge r750", "máy chủ dell") },
        @{ SKU="SRV-HPE-DL380"; KW=@("hpe proliant dl380", "proliant dl380", "hpe dl380", "máy chủ hpe") },
        @{ SKU="SW-CISCO-C9200L"; KW=@("cisco catalyst 9200l", "catalyst 9200l", "c9200l", "cisco 9200", "thiết bị chuyển mạch cisco", "switch cisco") },
        @{ SKU="FW-FORTINET-60F"; KW=@("fortigate 60f", "fortinet 60f", "tường lửa fortinet") },
        @{ SKU="AP-ARUBA-AP505"; KW=@("aruba instant on ap505", "aruba ap505", "aruba ap-505", "bộ phát wifi aruba", "wifi aruba") },
        @{ SKU="SAN-SYNOLOGY-RS2423"; KW=@("synology rackstation rs2423", "synology rs2423+", "synology rs2423", "nas synology", "rs2423") },
        @{ SKU="SVC-DEPLOY-BASIC"; KW=@("dịch vụ lắp đặt, cấu hình", "dịch vụ lắp đặt triển khai", "dịch vụ lắp đặt", "triển khai cơ bản", "lắp đặt triển khai") },
        @{ SKU="SVC-MAINTAIN-1Y"; KW=@("gói bảo trì định kỳ", "bảo trì định kỳ", "bảo trì 1 năm", "gói bảo trì") }
    )

    $modelNumbers = @(60, 505, 380, 750, 9200, 2423, 10)

    foreach ($entry in $kwMap) {
        foreach ($kw in $entry.KW) {
            if ($text.ToLower().Contains($kw.ToLower())) {
                $sku = $entry.SKU
                $catItem = $CatalogList | Where-Object { $_.sku -eq $sku } | Select-Object -First 1
                
                # Extract Quantity
                $qty = $null
                if ($sku -like "SVC-*") {
                    # Dịch vụ: mặc định 1 gói nếu được đề cập
                    $qty = 1
                    if ($text -match "(?i)(\d+)\s*(?:gói|hợp đồng|năm)") {
                        $qty = [int]$matches[1]
                    }
                } else {
                    # Mẫu 1: (0?[1-9]\d?)\s+(?:chiếc|bộ|cái|máy chủ|máy|thiết bị chuyển mạch|thiết bị|bộ phát|tường lửa)?\s*.*?(kw)
                    $p1 = "(?i)\b(0?[1-9]\d?)\s+(?:chiếc|bộ|cái|máy chủ|máy|thiết bị chuyển mạch|thiết bị|bộ phát|tường lửa)?\s*.*?" + [regex]::Escape($kw)
                    if ($text -match $p1) {
                        $candidate = [int]$matches[1]
                        if ($modelNumbers -notcontains $candidate) {
                            $qty = $candidate
                        }
                    }
                    
                    # Mẫu 2: (kw).*?(?:số lượng|sl|qty)\s*[:=]?\s*(\d+)
                    if ($null -eq $qty) {
                        $p2 = "(?i)" + [regex]::Escape($kw) + ".*?(?:số lượng|sl|qty)\s*[:=]?\s*(\d+)"
                        if ($text -match $p2) {
                            $candidate = [int]$matches[1]
                            if ($modelNumbers -notcontains $candidate) {
                                $qty = $candidate
                            }
                        }
                    }

                    # Mẫu 3: (báo giá|mua|cần|đặt mua)\s+(0?[1-9]\d?)\s+.*?(kw)
                    if ($null -eq $qty) {
                        $p3 = "(?i)(?:báo giá|mua|cần|đặt mua|trang bị)\s+(0?[1-9]\d?)\s+.*?" + [regex]::Escape($kw)
                        if ($text -match $p3) {
                            $candidate = [int]$matches[1]
                            if ($modelNumbers -notcontains $candidate) {
                                $qty = $candidate
                            }
                        }
                    }
                }

                $already = $items | Where-Object { $_.sku -eq $sku }
                if (-not $already) {
                    $items += [PSCustomObject]@{
                        sku = $sku
                        name = $catItem.name
                        quantity = $qty
                    }
                }
                break
            }
        }
    }

    if ($items.Count -eq 0) {
        if ($text.ToLower().Contains("máy chủ") -or $text.ToLower().Contains("lưu trữ") -or $text.ToLower().Contains("thiết bị") -or $text.ToLower().Contains("bộ phát")) {
            $items += [PSCustomObject]@{
                sku = $null
                name = "Thiết bị CNTT chưa rõ chủng loại / model"
                quantity = $null
            }
        }
    }

    foreach ($it in $items) {
        if ($null -eq $it.quantity) {
            $missingFields += "Số lượng cho hạng mục '$($it.name)'"
        }
    }
    if ($items.Count -eq 0) {
        $missingFields += "Danh mục sản phẩm hoặc dịch vụ cụ thể"
    }

    # Extract Budget
    $statedBudget = $null
    if ($text -match "(?i)(\d+(?:[\.,]\d+)?)\s*(?:tỷ|ty)") {
        $statedBudget = [double]($matches[1].Replace(",", ".")) * 1000000000
    } elseif ($text -match "(?i)(\d+(?:[\.,]\d+)?)\s*(?:triệu|trieu|tr\b)") {
        $statedBudget = [double]($matches[1].Replace(",", ".")) * 1000000
    } elseif ($text -match "(?i)(\d{1,3}(?:\.\d{3}){2,3})") {
        $statedBudget = [double]($matches[1].Replace(".", ""))
    }
    if ($null -eq $statedBudget) {
        $missingFields += "Tổng ngân sách dự kiến của khách hàng"
    }

    # Extract Deadline
    $deadlineDays = $null
    if ($text -match "(?i)(\d+)\s*(?:giờ|h|tiếng)") {
        $deadlineDays = [Math]::Max(1, [int][Math]::Round([double]$matches[1] / 24))
    } elseif ($text -match "(?i)(\d+)\s*ngày") {
        $deadlineDays = [int]$matches[1]
    } elseif ($text -match "(?i)(\d+)\s*tuần") {
        $deadlineDays = [int]$matches[1] * 7
    }
    if ($null -eq $deadlineDays) {
        $missingFields += "Thời hạn triển khai / bàn giao mong muốn"
    }

    # Extract Discount
    $discountPct = 0.0
    if ($text -match "(?i)(?:chiết khấu|giảm giá|discount)[^\d]{0,25}(\d+(?:[\.,]\d+)?)\s*%") {
        $discountPct = [double]($matches[1].Replace(",", "."))
    }

    if ([string]::IsNullOrWhiteSpace($Request.contact_person)) {
        $missingFields += "Người đại diện liên hệ / Người có thẩm quyền phê duyệt"
    }

    return [PSCustomObject]@{
        items = $items
        stated_budget = $statedBudget
        deadline_days = $deadlineDays
        discount_pct = $discountPct
        missing_fields = $missingFields
        has_critical = ($missingFields.Count -gt 0)
    }
}

# Tool 2: Catalog & Inventory
function Invoke-CatalogInventoryTool {
    param($Items, $DeadlineDays, $CatalogList)
    $isFullyStocked = $true
    $maxLeadTime = 0
    $detailedItems = @()

    foreach ($it in $Items) {
        $catItem = $CatalogList | Where-Object { $_.sku -eq $it.sku } | Select-Object -First 1
        if (-not $catItem) {
            $isFullyStocked = $false
            $detailedItems += [PSCustomObject]@{
                sku = $it.sku
                name = $it.name
                quantity = $it.quantity
                unit_price = 0
                line_amount = 0
                stock_available = 0
                is_sufficient = $false
                lead_time = 999
            }
            continue
        }

        $qty = if ($it.quantity) { [int]$it.quantity } else { 0 }
        $price = [double]$catItem.unit_price_vnd
        $lineAmount = $price * $qty
        $stock = [int]$catItem.available_stock
        $isSuff = ($qty -le $stock)
        
        $itemLead = if ($isSuff) { [int]$catItem.standard_lead_time_days } else { [int]$catItem.out_of_stock_lead_time_days }
        if (-not $isSuff) { $isFullyStocked = $false }
        if ($itemLead -gt $maxLeadTime) { $maxLeadTime = $itemLead }

        $detailedItems += [PSCustomObject]@{
            sku = $catItem.sku
            name = $catItem.name
            quantity = $qty
            unit_price = $price
            line_amount = $lineAmount
            stock_available = $stock
            is_sufficient = $isSuff
            lead_time = $itemLead
        }
    }

    $isDeadlineFeasible = $true
    $deadlineRiskNote = "Tiến độ khả thi"
    if ($null -ne $DeadlineDays) {
        if ($DeadlineDays -lt $maxLeadTime) {
            $isDeadlineFeasible = $false
            $deadlineRiskNote = "Khách hàng yêu cầu giao trong $DeadlineDays ngày < Thời gian tối thiểu $maxLeadTime ngày."
        }
    }

    return [PSCustomObject]@{
        detailed_items = $detailedItems
        is_fully_stocked = $isFullyStocked
        min_lead_time = $maxLeadTime
        is_deadline_feasible = $isDeadlineFeasible
        deadline_risk_note = $deadlineRiskNote
    }
}

# Tool 3: Pricing Policy & Escalation Matrix
function Invoke-PricingPolicyTool {
    param($Tier, $DetailedItems, $StatedBudget, $RequestedDiscount, $InventoryCheck, $Policy, $Matrix)
    $grossTotal = 0.0
    foreach ($it in $DetailedItems) { $grossTotal += $it.line_amount }

    # Tier discount
    $tierKey = $Tier.ToUpper()
    $tierDiscount = 0.0
    if ($Policy.customer_tiers.$tierKey) {
        $tierDiscount = [double]$Policy.customer_tiers.$tierKey.base_discount_pct
    }

    # Volume discount
    $volumeDiscount = 0.0
    foreach ($th in $Policy.volume_discount_thresholds) {
        if ($grossTotal -ge [double]$th.min_order_value_vnd -and $grossTotal -lt [double]$th.max_order_value_vnd) {
            $volumeDiscount = [double]$th.volume_discount_pct
            break
        }
    }

    $policyDiscount = $tierDiscount + $volumeDiscount
    $reqDisc = if ($RequestedDiscount) { [double]$RequestedDiscount } else { 0.0 }
    
    $effectiveDiscount = $policyDiscount
    $extraDiscount = 0.0
    if ($reqDisc -gt $policyDiscount) {
        $effectiveDiscount = [Math]::Min($reqDisc, [double]$Policy.max_allowable_discount_pct)
        $extraDiscount = $effectiveDiscount - $policyDiscount
    }

    $discountAmount = $grossTotal * ($effectiveDiscount / 100.0)
    $netTotal = $grossTotal - $discountAmount

    # Check approval levels
    $reasons = @()
    $level = "SALES_REP"

    if ($extraDiscount -gt 10.0 -or $effectiveDiscount -gt 12.0) {
        $level = "BOD"
        $reasons += "Mức chiết khấu đề nghị ($([string]::Format('{0:N1}', $effectiveDiscount))%) thuộc thẩm quyền của Ban Giám đốc"
    } elseif ($extraDiscount -gt 3.0) {
        if ($level -ne "BOD") { $level = "SALES_MANAGER" }
        $reasons += "Mức chiết khấu vượt thẩm quyền Sales ($([string]::Format('{0:N1}', $extraDiscount))% > 3%) cần Trưởng phòng duyệt"
    }

    if ($netTotal -ge 500000000) {
        $level = "BOD"
        $reasons += "Tổng giá trị đơn hàng ($([string]::Format('{0:N0}', $netTotal)) VNĐ >= 500M) cần Ban Giám đốc phê duyệt"
    } elseif ($netTotal -gt 200000000) {
        if ($level -ne "BOD") { $level = "SALES_MANAGER" }
        $reasons += "Tổng giá trị đơn hàng ($([string]::Format('{0:N0}', $netTotal)) VNĐ > 200M) vượt thẩm quyền Sales Rep"
    }

    if (-not $InventoryCheck.is_fully_stocked) {
        if ($level -ne "BOD") { $level = "SALES_MANAGER" }
        $reasons += "Tồn kho không đủ đáp ứng, cần điều phối nhập hàng đặc biệt"
    }

    if (-not $InventoryCheck.is_deadline_feasible) {
        if ($level -ne "BOD") { $level = "SALES_MANAGER" }
        $reasons += $InventoryCheck.deadline_risk_note
    }

    if ($null -ne $StatedBudget -and $StatedBudget -gt 0) {
        if ($StatedBudget -lt $netTotal) {
            $shortfall = (($netTotal - $StatedBudget) / $netTotal) * 100.0
            if ($shortfall -gt 15.0) {
                if ($level -ne "BOD") { $level = "SALES_MANAGER" }
                $reasons += "Ngân sách khách hàng thiếu hụt $([string]::Format('{0:N1}', $shortfall))% so với giá trị đề xuất sau chiết khấu"
            }
        }
    }

    return [PSCustomObject]@{
        gross_total = $grossTotal
        net_total = $netTotal
        effective_discount = $effectiveDiscount
        extra_discount = $extraDiscount
        policy_discount = $policyDiscount
        required_level = $level
        escalation_reasons = $reasons
    }
}

# Run Agent Batch
$results = @()
$canProceedCount = 0
$needsInfoCount = 0
$cannotFulfillCount = 0
$pendingApprovalCount = 0
$totalQualifiedOrPending = 0.0

foreach ($req in $Requests) {
    $reqId = $req.id
    $oppId = "OPP-" + $reqId.Replace("REQ-", "")

    Log-Audit -RequestId $reqId -EventType "WORKFLOW_STEP" -StepName "START_PIPELINE" -Message "Tiếp nhận yêu cầu từ $($req.customer_name)"

    # Tool 1: Extraction
    $ext = Invoke-ExtractionTool -Request $req -CatalogList $Catalog
    Log-Audit -RequestId $reqId -EventType "TOOL_INVOCATION" -StepName "ExtractionTool" -Message "Trích xuất thành công" -Details "items=$($ext.items.Count), missing=$($ext.missing_fields.Count)"

    # Guardrail 1: Check Critical Missing Data
    $hasUnspecified = ($ext.items.Count -eq 0 -or ($ext.items | Where-Object { $null -eq $_.quantity -or $null -eq $_.sku }))
    if ($ext.has_critical -and $hasUnspecified) {
        Log-Audit -RequestId $reqId -EventType "GUARDRAIL_TRIGGERED" -StepName "GUARDRAIL_MISSING_DATA" -Message "Khóa quy trình do thiếu dữ liệu bắt buộc" -Details ($ext.missing_fields -join ", ")
        $status = "NEEDS_INFO"
        $needsInfoCount++
        $missingItemsList = ($ext.missing_fields | ForEach-Object { "- $_" }) -join "`n"
        $dossierText = @"
# HỒ SƠ CƠ HỘI BÁN HÀNG B2B - $oppId
**Mã yêu cầu gốc**: $reqId | **Khách hàng**: $($req.customer_name)
**Trạng thái**: NEEDS_INFO (Cần bổ sung thông tin)
**Căn cứ**: Thiếu dữ liệu bắt buộc để định giá ($($ext.missing_fields -join '; '))
**Bước tiếp theo**: Gửi email phản hồi đề nghị bổ sung chi tiết số lượng và quy cách kỹ thuật.

## THÔNG TIN CÒN THIẾU:
$missingItemsList
"@
        $dossierPath = Join-Path $DossiersDir "Dossier_$oppId.md"
        $dossierText | Out-File -FilePath $dossierPath -Encoding UTF8

        # Draft Email
        $missingBullets = ($ext.missing_fields | ForEach-Object { "  - $_" }) -join "`n"
        $emailText = @"
TO: $($req.contact_email) ($($req.contact_person))
SUBJECT: [Minh An Technology] Xác nhận và xin bổ sung thông tin yêu cầu - $($req.customer_name)
TYPE: CLARIFICATION_REQUEST
======================================================================

Kính gửi $($req.contact_person),
Đại diện $($req.customer_name),

Công ty Minh An trân trọng cảm ơn Quý công ty đã liên hệ.
Để có thể lập Báo giá chính xác nhất, kính đề nghị Quý khách hỗ trợ làm rõ một số nội dung sau:
$missingBullets

Trân trọng,
Bộ phận Kinh doanh Doanh nghiệp (B2B) - Công ty Công nghệ Minh An
"@
        $emailPath = Join-Path $DraftEmailsDir "Email_$oppId.txt"
        $emailText | Out-File -FilePath $emailPath -Encoding UTF8

        $results += [PSCustomObject]@{
            opp_id = $oppId
            customer = $req.customer_name
            status = $status
            net_total = 0
            approval_level = "SALES_REP"
        }
        continue
    }

    # Tool 2: Inventory
    $inv = Invoke-CatalogInventoryTool -Items $ext.items -DeadlineDays $ext.deadline_days -CatalogList $Catalog
    Log-Audit -RequestId $reqId -EventType "TOOL_INVOCATION" -StepName "CatalogInventoryTool" -Message "Đối chiếu kho và SLA" -Details "lead_time=$($inv.min_lead_time), stock_ok=$($inv.is_fully_stocked)"

    # Tool 3: Pricing & Escalation
    $prc = Invoke-PricingPolicyTool -Tier $req.tier -DetailedItems $inv.detailed_items -StatedBudget $ext.stated_budget -RequestedDiscount $ext.discount_pct -InventoryCheck $inv -Policy $DiscountPolicy -Matrix $ApprovalMatrix
    Log-Audit -RequestId $reqId -EventType "TOOL_INVOCATION" -StepName "PricingPolicyTool" -Message "Tính giá và thẩm quyền" -Details "net=$($prc.net_total), level=$($prc.required_level)"

    # Status classification & Guardrails
    if (-not $inv.is_deadline_feasible -and $null -ne $ext.deadline_days -and $ext.deadline_days -le 1) {
        $status = "CANNOT_FULFILL"
        $cannotFulfillCount++
        Log-Audit -RequestId $reqId -EventType "GUARDRAIL_TRIGGERED" -StepName "GUARDRAIL_UNREALISTIC_DEADLINE" -Message "Không thể đáp ứng thời hạn 24h"
    } elseif ($prc.required_level -ne "SALES_REP") {
        $status = "PENDING_APPROVAL"
        $pendingApprovalCount++
        $totalQualifiedOrPending += $prc.net_total
        Log-Audit -RequestId $reqId -EventType "GUARDRAIL_TRIGGERED" -StepName "GUARDRAIL_AUTHORITY_LIMIT" -Message "Vượt quyền Sales Rep, chuyển $($prc.required_level)" -Details ($prc.escalation_reasons -join "; ")
        
        # Tạo phiếu chuyển duyệt
        $reasonsList = ($prc.escalation_reasons | ForEach-Object { "- 🔴 $_" }) -join "`n"
        $targetLevel = $prc.required_level
        $ticketIdStr = "TICKET-$oppId"
        $netTotalStr = [string]::Format('{0:N0}', $prc.net_total)
        $discStr = [string]::Format('{0:N1}', $prc.effective_discount)
        $ticketText = @"
# PHIẾU CHUYỂN DUYỆT CƠ HỘI BÁN HÀNG VƯỢT THẨM QUYỀN
**Mã Phiếu**: $ticketIdStr | **Cấp duyệt**: $targetLevel
**Khách hàng**: $($req.customer_name)
**Giá trị đơn hàng (Net)**: $netTotalStr VNĐ (Chiết khấu: $discStr%)
**Căn cứ chuyển duyệt**:
$reasonsList
"@
        $ticketPath = Join-Path $ApprovalTicketsDir "Ticket_TICKET-$oppId.md"
        $ticketText | Out-File -FilePath $ticketPath -Encoding UTF8
    } else {
        $status = "CAN_PROCEED"
        $canProceedCount++
        $totalQualifiedOrPending += $prc.net_total
        Log-Audit -RequestId $reqId -EventType "WORKFLOW_STEP" -StepName "CAN_PROCEED" -Message "Hồ sơ đủ điều kiện tiếp tục bán hàng"
    }

    # Generate Dossier Markdown
    $tableRows = @()
    foreach ($lineItem in $inv.detailed_items) {
        $stockIcon = if ($lineItem.is_sufficient) { "✅ Đủ hàng" } else { "⚠️ Thiếu kho" }
        $lineSku = $lineItem.sku
        $tableRows += "| '$lineSku' | $($lineItem.name) | $($lineItem.quantity) | $([string]::Format('{0:N0}', $lineItem.unit_price)) | $([string]::Format('{0:N0}', $lineItem.line_amount)) | $($lineItem.stock_available) | $stockIcon |"
    }
    $itemsTable = $tableRows -join "`n"

    $reasonsMarkdown = if ($prc.escalation_reasons.Count -gt 0) {
        ($prc.escalation_reasons | ForEach-Object { "- ⚠️ $_" }) -join "`n"
    } else {
        "- Không có lý do ngoại lệ (Trong hạn mức tự duyệt)."
    }

    $budgetStr = if ($ext.stated_budget) { [string]::Format('{0:N0} VNĐ', $ext.stated_budget) } else { "Không công bố" }
    $reqDaysStr = if ($ext.deadline_days) { "$($ext.deadline_days) ngày" } else { "Không nêu" }
    $reqLevel = $prc.required_level

    $dossierText = @"
# HỒ SƠ CƠ HỘI BÁN HÀNG B2B - $oppId
**Mã yêu cầu gốc**: $reqId | **Khách hàng**: $($req.customer_name)
**Đại diện**: $($req.contact_person) | **Email**: $($req.contact_email)
**Trạng thái**: $status | **Cấp thẩm quyền**: $reqLevel

## BẢNG ĐỐI CHIẾU HẠNG MỤC & TỒN KHO:
| SKU | Tên Hạng Mục | SL | Đơn Giá (VNĐ) | Thành Tiền (VNĐ) | Tồn Kho | Trạng Thái |
| --- | --- | ---: | ---: | ---: | ---: | :---: |
$itemsTable

## THÔNG SỐ TÀI CHÍNH:
- Tổng giá trị niêm yết: $([string]::Format('{0:N0}', $prc.gross_total)) VNĐ
- Chiết khấu áp dụng: $([string]::Format('{0:N1}', $prc.effective_discount))%
- **Tổng giá trị thanh toán (Net)**: $([string]::Format('{0:N0}', $prc.net_total)) VNĐ
- Ngân sách khách hàng: $budgetStr
- Thời gian đáp ứng: $($inv.min_lead_time) ngày (Khách yêu cầu: $reqDaysStr)

## LÝ DO CHUYỂN DUYỆT / LƯU Ý:
$reasonsMarkdown
"@
    $dossierPath = Join-Path $DossiersDir "Dossier_$oppId.md"
    $dossierText | Out-File -FilePath $dossierPath -Encoding UTF8

    # Generate Draft Email
    $emailSubject = if ($status -eq "CAN_PROCEED") {
        "[Minh An Technology] Báo giá chính thức & Kế hoạch triển khai - $($req.customer_name)"
    } elseif ($status -eq "PENDING_APPROVAL") {
        "[Minh An Technology] Đề xuất sơ bộ & Tiếp nhận hồ sơ chào giá - $($req.customer_name)"
    } else {
        "[Minh An Technology] Phản hồi yêu cầu giải pháp & Đề xuất phương án - $($req.customer_name)"
    }

    $emailBodyText = if ($status -eq "CAN_PROCEED") {
"Chúng tôi xin gửi Báo giá chính thức với tổng giá trị thanh toán là $([string]::Format('{0:N0}', $prc.net_total)) VNĐ (Đã áp dụng chiết khấu $([string]::Format('{0:N1}', $prc.effective_discount))%).
Toàn bộ thiết bị có sẵn trong kho, thời gian bàn giao nghiệm thu trong $($inv.min_lead_time) ngày làm việc."
    } elseif ($status -eq "PENDING_APPROVAL") {
"Đơn hàng của Quý khách với giá trị $([string]::Format('{0:N0}', $prc.net_total)) VNĐ và mức chiết khấu $([string]::Format('{0:N1}', $prc.effective_discount))% đang được trình $($prc.required_level) phê duyệt đặc biệt. Chúng tôi sẽ phản hồi chính thức trước 17h00 hôm nay."
    } else {
"Do yêu cầu bàn giao hỏa tốc trong $($ext.deadline_days) ngày ngắn hơn quy trình chuẩn ($($inv.min_lead_time) ngày), Minh An kính đề xuất phương án giao trước đợt 1 hoặc thay thế bằng cấu hình tương đương có sẵn."
    }

    $emailTypeStr = if ($status -eq 'CAN_PROCEED') { 'OFFICIAL_QUOTATION' } elseif ($status -eq 'PENDING_APPROVAL') { 'PRELIMINARY_PROPOSAL' } else { 'ALTERNATIVE_OFFER' }
    $emailText = @"
TO: $($req.contact_email) ($($req.contact_person))
SUBJECT: $emailSubject
TYPE: $emailTypeStr
======================================================================

Kính gửi $($req.contact_person),
Đại diện $($req.customer_name),

Công ty Minh An trân trọng cảm ơn Quý khách.
$emailBodyText

Trân trọng,
Bộ phận Kinh doanh Doanh nghiệp (B2B) - Công ty Công nghệ Minh An
"@
    $emailPath = Join-Path $DraftEmailsDir "Email_$oppId.txt"
    $emailText | Out-File -FilePath $emailPath -Encoding UTF8

    $results += [PSCustomObject]@{
        opp_id = $oppId
        customer = $req.customer_name
        status = $status
        net_total = $prc.net_total
        approval_level = $prc.required_level
    }
}

# In bảng kết quả
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "                     KẾT QUẢ XỬ LÝ TỪNG CƠ HỘI KINH DOANH                       " -ForegroundColor Green
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ("{0,-12} | {1,-26} | {2,-18} | {3,16} | {4,-14}" -f "MÃ OPP", "KHÁCH HÀNG", "TRẠNG THÁI", "GIÁ TRỊ (VNĐ)", "CẤP DUYỆT") -ForegroundColor White
Write-Host ("-" * 95) -ForegroundColor DarkGray

foreach ($r in $results) {
    $valStr = if ($r.net_total -gt 0) { [string]::Format('{0:N0}', $r.net_total) } else { "0" }
    $color = if ($r.status -eq "CAN_PROCEED") { "Green" } elseif ($r.status -eq "PENDING_APPROVAL") { "Yellow" } elseif ($r.status -eq "NEEDS_INFO") { "Cyan" } else { "Magenta" }
    Write-Host ("{0,-12} | {1,-26} | {2,-18} | {3,16} | {4,-14}" -f $r.opp_id, $r.customer.PadRight(26).Substring(0, 26), $r.status, $valStr, $r.approval_level) -ForegroundColor $color
}

Write-Host "`n================================================================================" -ForegroundColor Cyan
Write-Host "             BẢNG TỔNG HỢP THEO QUY CHUẨN BAN GIÁM ĐỐC MINH AN                  " -ForegroundColor Yellow
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "  * Tổng số yêu cầu đã tiếp nhận và xử lý:  $($Requests.Count)" -ForegroundColor White
Write-Host "  * [1] Số cơ hội CÓ THỂ TIẾP TỤC:          $canProceedCount" -ForegroundColor Green
Write-Host "  * [2] Số cơ hội CẦN BỔ SUNG THÔNG TIN:    $needsInfoCount" -ForegroundColor Cyan
Write-Host "  * [3] Số cơ hội CHƯA ĐÁP ỨNG:             $cannotFulfillCount" -ForegroundColor Magenta
Write-Host "  * [4] Số cơ hội CHỜ PHÊ DUYỆT (vượt quyền): $pendingApprovalCount" -ForegroundColor Yellow
Write-Host ("-" * 80) -ForegroundColor DarkGray
Write-Host "  >>> TỔNG GIÁ TRỊ CÁC CƠ HỘI ĐỦ ĐIỀU KIỆN TIẾP TỤC HOẶC CHỜ DUYỆT:" -ForegroundColor White
Write-Host ("      {0:N0} VNĐ" -f $totalQualifiedOrPending) -ForegroundColor Green
Write-Host "================================================================================`n" -ForegroundColor Cyan

# Lưu summary dashboard JSON
$summaryObj = @{
    total_requests_processed = $Requests.Count
    summary_counts = @{
        can_proceed = $canProceedCount
        needs_info = $needsInfoCount
        cannot_fulfill = $cannotFulfillCount
        pending_approval = $pendingApprovalCount
    }
    financial_summary = @{
        total_qualified_or_pending_value_vnd = $totalQualifiedOrPending
        total_qualified_or_pending_value_formatted = ("{0:N0} VNĐ" -f $totalQualifiedOrPending)
    }
    timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss")
}

$summaryJsonPath = Join-Path $OutputDir "summary_dashboard.json"
$summaryObj | ConvertTo-Json -Depth 5 | Out-File -FilePath $summaryJsonPath -Encoding UTF8

Write-Host "[THÀNH CÔNG] Hồ sơ cơ hội đã xuất tại: $DossiersDir" -ForegroundColor White
Write-Host "[THÀNH CÔNG] Bản nháp email đã xuất tại: $DraftEmailsDir" -ForegroundColor White
Write-Host "[THÀNH CÔNG] Phiếu chuyển duyệt đã xuất tại: $ApprovalTicketsDir" -ForegroundColor White
Write-Host "[THÀNH CÔNG] Nhật ký truy vết Audit Trail tại: $AuditLogFile" -ForegroundColor White
