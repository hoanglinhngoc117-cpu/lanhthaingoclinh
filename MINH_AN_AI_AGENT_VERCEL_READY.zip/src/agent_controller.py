import json
from pathlib import Path
from typing import List, Dict, Any, Optional

from src.models import (
    CustomerRequest, OpportunityDossier, OpportunityStatus, 
    ApprovalLevel, DraftEmail, ApprovalTicket
)
from src.tools.extraction_tool import ExtractionTool
from src.tools.catalog_inventory_tool import CatalogInventoryTool
from src.tools.pricing_policy_tool import PricingPolicyTool
from src.tools.generator_tool import GeneratorTool
from src.audit_logger import AuditLogger
from src.config import (
    PRODUCTS_CATALOG_PATH, DISCOUNT_POLICY_PATH, APPROVAL_MATRIX_PATH,
    SUMMARY_DASHBOARD_PATH
)

class MinhAnB2BAgent:
    """
    Coordinator Agent cho bài toán Xử lý cơ hội bán hàng B2B Công ty Minh An.
    Tích hợp 4 kỹ năng nghiệp vụ (Tools), cơ chế Guardrails và Audit Trail.
    """
    def __init__(self):
        self.audit_logger = AuditLogger()
        self._load_knowledge_base()
        
        # Khởi tạo các kỹ năng nghiệp vụ (Business Skills / Tools)
        self.extraction_tool = ExtractionTool(self.catalog_data)
        self.inventory_tool = CatalogInventoryTool(self.catalog_data)
        self.pricing_tool = PricingPolicyTool(self.discount_policy_data, self.approval_matrix_data)
        self.generator_tool = GeneratorTool()

    def _load_knowledge_base(self):
        with open(PRODUCTS_CATALOG_PATH, "r", encoding="utf-8") as f:
            self.catalog_data = json.load(f)
        with open(DISCOUNT_POLICY_PATH, "r", encoding="utf-8") as f:
            self.discount_policy_data = json.load(f)
        with open(APPROVAL_MATRIX_PATH, "r", encoding="utf-8") as f:
            self.approval_matrix_data = json.load(f)

    def process_request(self, raw_request: CustomerRequest) -> Dict[str, Any]:
        req_id = raw_request.id
        opp_id = f"OPP-{req_id.replace('REQ-', '')}"
        
        self.audit_logger.log_step(
            req_id, "START_PIPELINE", 
            f"Bắt đầu tiếp nhận và xử lý yêu cầu từ {raw_request.customer_name}"
        )

        # -------------------------------------------------------------
        # BƯỚC 1: TRÍCH XUẤT THỰC THỂ & KIỂM TRA THÔNG TIN CÒN THIẾU (Tool 1)
        # -------------------------------------------------------------
        self.audit_logger.log_step(req_id, "INVOKE_TOOL_1", "Gọi ExtractionTool để phân tích văn bản")
        extraction_res = self.extraction_tool.execute(raw_request)
        self.audit_logger.log_tool_call(
            req_id, "ExtractionTool", 
            {"text_length": len(raw_request.raw_request_text), "customer_tier": raw_request.tier},
            {
                "items_count": len(extraction_res.items),
                "stated_budget": extraction_res.stated_budget_vnd,
                "deadline_days": extraction_res.requested_deadline_days,
                "missing_fields": extraction_res.missing_fields
            }
        )

        # GUARDRAIL 1: KIỂM TRA DỮ LIỆU CỐT LÕI (Không tự ý chào bán khi thiếu dữ liệu trọng yếu)
        if extraction_res.has_critical_missing_info:
            has_no_items = len(extraction_res.items) == 0
            has_unspecified_items = any(it.sku is None or it.quantity is None for it in extraction_res.items)
            
            if has_no_items or has_unspecified_items:
                self.audit_logger.log_guardrail_trigger(
                    req_id, "GUARDRAIL_MISSING_CRITICAL_DATA",
                    f"Yêu cầu thiếu dữ liệu trọng yếu: {', '.join(extraction_res.missing_fields)}",
                    "Khóa quy trình tính giá; chuyển trạng thái sang NEEDS_INFO; soạn email yêu cầu làm rõ."
                )

                # Chạy inventory và pricing rỗng để tạo hồ sơ
                _, inv_res = self.inventory_tool.execute([], None)
                pricing_res = self.pricing_tool.execute(raw_request.tier, [], None, 0.0, inv_res)

                dossier = self.generator_tool.generate_dossier(
                    opp_id=opp_id,
                    extraction=extraction_res,
                    inventory=inv_res,
                    pricing=pricing_res,
                    status=OpportunityStatus.NEEDS_INFO,
                    basis_of_decision=f"Thiếu thông tin bắt buộc để định giá ({', '.join(extraction_res.missing_fields)})",
                    next_action="Gửi email phản hồi đề nghị khách hàng cung cấp bổ sung chi tiết số lượng và quy cách kỹ thuật."
                )
                email = self.generator_tool.generate_draft_email(dossier)
                
                self.audit_logger.log_step(req_id, "COMPLETED_WITH_NEEDS_INFO", "Đã tạo hồ sơ chờ bổ sung thông tin")
                return {
                    "dossier": dossier,
                    "email": email,
                    "ticket": None,
                    "status": OpportunityStatus.NEEDS_INFO
                }

        # -------------------------------------------------------------
        # BƯỚC 2: TRA CỨU DANH MỤC & ĐỐI CHIẾU TỒN KHO KHẢ DỤNG (Tool 2)
        # -------------------------------------------------------------
        self.audit_logger.log_step(req_id, "INVOKE_TOOL_2", "Gọi CatalogInventoryTool để kiểm tra bảng giá mới và kho hàng")
        updated_items, inv_res = self.inventory_tool.execute(
            extraction_res.items, extraction_res.requested_deadline_days
        )
        extraction_res.items = updated_items
        self.audit_logger.log_tool_call(
            req_id, "CatalogInventoryTool",
            {"items": [it.sku for it in updated_items], "requested_deadline": extraction_res.requested_deadline_days},
            {
                "is_fully_stocked": inv_res.is_fully_stocked,
                "lead_time": inv_res.min_required_lead_time_days,
                "deadline_feasible": inv_res.is_deadline_feasible
            }
        )

        # -------------------------------------------------------------
        # BƯỚC 3: TÍNH TOÁN GIÁ TRỊ, CHÍNH SÁCH CHIẾT KHẤU & PHÂN QUYỀN (Tool 3)
        # -------------------------------------------------------------
        self.audit_logger.log_step(req_id, "INVOKE_TOOL_3", "Gọi PricingPolicyTool để tính toán tài chính và thẩm quyền duyệt")
        pricing_res = self.pricing_tool.execute(
            customer_tier=raw_request.tier,
            items=updated_items,
            stated_budget_vnd=extraction_res.stated_budget_vnd,
            requested_discount_pct=extraction_res.requested_discount_pct or 0.0,
            inventory_result=inv_res
        )
        self.audit_logger.log_tool_call(
            req_id, "PricingPolicyTool",
            {
                "gross_total": pricing_res.gross_total_vnd,
                "discount_pct": pricing_res.effective_discount_pct,
                "net_total": pricing_res.net_total_vnd
            },
            {
                "required_approval": pricing_res.required_approval_level.value,
                "escalation_reasons": pricing_res.escalation_reasons,
                "budget_comparison": pricing_res.budget_comparison
            }
        )

        # -------------------------------------------------------------
        # BƯỚC 4: TỔNG HỢP RA QUYẾT ĐỊNH & THIẾT LẬP GUARDRAIL
        # -------------------------------------------------------------
        # Phân loại trạng thái cuối cùng
        ticket: Optional[ApprovalTicket] = None

        # Trường hợp 1: Không thể đáp ứng (CANNOT_FULFILL)
        # Nếu deadline quá ngắn đến mức bất khả thi (ví dụ khách đòi giao trong 1 ngày nhưng SLA server 3 ngày)
        # hoặc khách hàng không có ngân sách hoàn toàn không thể đàm phán
        if not inv_res.is_deadline_feasible and extraction_res.requested_deadline_days is not None and extraction_res.requested_deadline_days <= 1:
            status = OpportunityStatus.CANNOT_FULFILL
            basis_of_decision = f"Thời hạn khách hàng yêu cầu ({extraction_res.requested_deadline_days} ngày) không thể đáp ứng kỹ thuật (tối thiểu {inv_res.min_required_lead_time_days} ngày)."
            next_action = "Gửi email đề xuất điều chỉnh thời gian giao hàng hoặc thay thế bằng phương án khả thi; chuyên viên gọi điện tư vấn."
            self.audit_logger.log_guardrail_trigger(
                req_id, "GUARDRAIL_UNREALISTIC_DEADLINE",
                f"Thời hạn yêu cầu {extraction_res.requested_deadline_days} ngày < SLA {inv_res.min_required_lead_time_days} ngày",
                "Chuyển trạng thái CANNOT_FULFILL, ngăn chặn hứa hẹn sai thời hạn."
            )

        # Trường hợp 2: Chờ phê duyệt vượt thẩm quyền (PENDING_APPROVAL)
        elif pricing_res.required_approval_level != ApprovalLevel.SALES_REP:
            status = OpportunityStatus.PENDING_APPROVAL
            basis_of_decision = f"Vượt thẩm quyền tự quyết của Sales Rep ({'; '.join(pricing_res.escalation_reasons)}). Chuyển {pricing_res.required_approval_level.value} duyệt."
            next_action = f"Lập Phiếu chuyển duyệt trình {pricing_res.required_approval_level.value} xem xét; đồng thời gửi thư báo tiến nhận hồ sơ cho khách hàng."
            self.audit_logger.log_guardrail_trigger(
                req_id, "GUARDRAIL_AUTHORITY_LIMIT",
                f"Đơn hàng vượt trần quyền hạn Sales Rep: {', '.join(pricing_res.escalation_reasons)}",
                f"Cấm chốt bán tự động; tạo Approval Ticket chuyển {pricing_res.required_approval_level.value}."
            )

        # Trường hợp 3: Có thể tiếp tục (CAN_PROCEED)
        else:
            status = OpportunityStatus.CAN_PROCEED
            basis_of_decision = "Dữ liệu đầy đủ; Hàng hóa có sẵn; Chiết khấu và giá trị đơn hàng trong hạn mức tự quyết của Nhân viên Kinh doanh."
            next_action = "Gửi Báo giá chính thức và Hợp đồng mẫu cho khách hàng; phân công Sales Rep theo dõi chốt đơn."

        # -------------------------------------------------------------
        # BƯỚC 5: TẠO HỒ SƠ CƠ HỘI, EMAIL NHÁP & PHIẾU CHUYỂN DUYỆT (Tool 4)
        # -------------------------------------------------------------
        self.audit_logger.log_step(req_id, "INVOKE_TOOL_4", "Gọi GeneratorTool để xuất hồ sơ, email và phiếu chuyển duyệt")
        dossier = self.generator_tool.generate_dossier(
            opp_id=opp_id,
            extraction=extraction_res,
            inventory=inv_res,
            pricing=pricing_res,
            status=status,
            basis_of_decision=basis_of_decision,
            next_action=next_action
        )

        email = self.generator_tool.generate_draft_email(dossier)

        if status == OpportunityStatus.PENDING_APPROVAL:
            ticket = self.generator_tool.generate_approval_ticket(dossier, pricing_res)

        self.audit_logger.log_step(
            req_id, "END_PIPELINE", 
            f"Hoàn thành xử lý cơ hội {opp_id} với trạng thái {status.value}"
        )

        return {
            "dossier": dossier,
            "email": email,
            "ticket": ticket,
            "status": status
        }

    def process_batch(self, requests_list: List[CustomerRequest]) -> Dict[str, Any]:
        results = []
        counts = {
            "CAN_PROCEED": 0,
            "NEEDS_INFO": 0,
            "CANNOT_FULFILL": 0,
            "PENDING_APPROVAL": 0
        }
        total_qualified_or_pending_value = 0.0

        for req in requests_list:
            res = self.process_request(req)
            results.append(res)
            st = res["status"].value
            counts[st] = counts.get(st, 0) + 1
            
            # Tính riêng tổng giá trị các cơ hội đủ điều kiện tiếp tục hoặc chờ duyệt
            if res["status"] in [OpportunityStatus.CAN_PROCEED, OpportunityStatus.PENDING_APPROVAL]:
                total_qualified_or_pending_value += res["dossier"].net_total_vnd

        summary_dashboard = {
            "total_requests_processed": len(requests_list),
            "summary_counts": {
                "can_proceed": counts["CAN_PROCEED"],
                "needs_info": counts["NEEDS_INFO"],
                "cannot_fulfill": counts["CANNOT_FULFILL"],
                "pending_approval": counts["PENDING_APPROVAL"]
            },
            "financial_summary": {
                "total_qualified_or_pending_value_vnd": total_qualified_or_pending_value,
                "total_qualified_or_pending_value_formatted": f"{total_qualified_or_pending_value:,.0f} VNĐ"
            },
            "timestamp": "2026-11-11T10:00:00"
        }

        # Lưu file tổng hợp
        try:
            with open(SUMMARY_DASHBOARD_PATH, "w", encoding="utf-8") as f:
                json.dump(summary_dashboard, f, ensure_ascii=False, indent=2)
        except OSError:
            pass

        return {
            "results": results,
            "dashboard": summary_dashboard
        }

