import sys
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict
from src.config import AUDIT_LOG_PATH

class AuditLogger:
    def __init__(self, log_file: Path = AUDIT_LOG_PATH):
        self.log_file = log_file
        self.entries = []
        # Setup logger
        self.logger = logging.getLogger("MinhAnAgentAudit")
        self.logger.setLevel(logging.INFO)
        if not self.logger.handlers:
            try:
                # Đảm bảo thư mục cha tồn tại
                self.log_file.parent.mkdir(parents=True, exist_ok=True)
                fh = logging.FileHandler(self.log_file, encoding="utf-8", mode="a")
                formatter = logging.Formatter("[%(asctime)s] %(levelname)s: %(message)s")
                fh.setFormatter(formatter)
                self.logger.addHandler(fh)
            except Exception:
                # Fallback to stdout trên môi trường serverless/read-only
                sh = logging.StreamHandler(sys.stdout)
                formatter = logging.Formatter("[%(asctime)s] %(levelname)s: %(message)s")
                sh.setFormatter(formatter)
                self.logger.addHandler(sh)

    def log_step(self, request_id: str, step_name: str, message: str, details: Dict[str, Any] = None):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "request_id": request_id,
            "event_type": "WORKFLOW_STEP",
            "step_name": step_name,
            "message": message,
            "details": details or {}
        }
        self.entries.append(entry)
        self.logger.info(f"[{request_id}] STEP={step_name} | {message} | details={json.dumps(details or {}, ensure_ascii=False)}")

    def log_tool_call(self, request_id: str, tool_name: str, input_args: Dict[str, Any], output_result: Any):
        if hasattr(output_result, "__dict__"):
            out_repr = str(output_result.__dict__)
        else:
            out_repr = str(output_result)
        if len(out_repr) > 400:
            out_repr = out_repr[:400] + "... [truncated]"

        entry = {
            "timestamp": datetime.now().isoformat(),
            "request_id": request_id,
            "event_type": "TOOL_INVOCATION",
            "tool_name": tool_name,
            "input_args": input_args,
            "output_summary": out_repr
        }
        self.entries.append(entry)
        self.logger.info(f"[{request_id}] TOOL_CALL={tool_name} | args={json.dumps(input_args, ensure_ascii=False)} | out={out_repr}")

    def log_guardrail_trigger(self, request_id: str, guardrail_rule: str, reason: str, action_taken: str):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "request_id": request_id,
            "event_type": "GUARDRAIL_TRIGGERED",
            "rule": guardrail_rule,
            "reason": reason,
            "action_taken": action_taken
        }
        self.entries.append(entry)
        self.logger.warning(f"[{request_id}] GUARDRAIL={guardrail_rule} | REASON={reason} | ACTION={action_taken}")

    def get_audit_trail(self):
        return self.entries
