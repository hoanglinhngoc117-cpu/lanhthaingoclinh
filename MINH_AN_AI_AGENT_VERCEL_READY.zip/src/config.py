import os
import shutil
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
REPO_OUTPUT_DIR = BASE_DIR / "output"

# Kiểm tra nếu đang chạy trên Vercel hoặc môi trường Serverless (Read-only filesystem)
IS_VERCEL = os.environ.get("VERCEL") is not None or os.environ.get("AWS_LAMBDA_FUNCTION_NAME") is not None

if IS_VERCEL:
    OUTPUT_DIR = Path("/tmp/output")
    # Tự động sao chép dữ liệu output sẵn có vào /tmp để vừa có đủ hồ sơ vừa ghi được file mới
    if REPO_OUTPUT_DIR.exists() and not OUTPUT_DIR.exists():
        try:
            shutil.copytree(REPO_OUTPUT_DIR, OUTPUT_DIR)
        except Exception:
            pass
else:
    OUTPUT_DIR = REPO_OUTPUT_DIR

PRODUCTS_CATALOG_PATH = DATA_DIR / "products_catalog.json"
DISCOUNT_POLICY_PATH = DATA_DIR / "discount_policy.json"
APPROVAL_MATRIX_PATH = DATA_DIR / "approval_matrix.json"
SAMPLE_REQUESTS_PATH = DATA_DIR / "sample_requests.json"

DOSSIERS_DIR = OUTPUT_DIR / "dossiers"
DRAFT_EMAILS_DIR = OUTPUT_DIR / "draft_emails"
APPROVAL_TICKETS_DIR = OUTPUT_DIR / "approval_tickets"
LOGS_DIR = OUTPUT_DIR / "logs"
AUDIT_LOG_PATH = LOGS_DIR / "execution_audit.log"
SUMMARY_DASHBOARD_PATH = OUTPUT_DIR / "summary_dashboard.json"

for d in [DATA_DIR, OUTPUT_DIR, DOSSIERS_DIR, DRAFT_EMAILS_DIR, APPROVAL_TICKETS_DIR, LOGS_DIR]:
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
