from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from enum import Enum

class OpportunityStatus(str, Enum):
    CAN_PROCEED = "CAN_PROCEED"             # Có thể tiếp tục
    NEEDS_INFO = "NEEDS_INFO"               # Cần bổ sung thông tin
    CANNOT_FULFILL = "CANNOT_FULFILL"       # Chưa đáp ứng được
    PENDING_APPROVAL = "PENDING_APPROVAL"   # Chờ phê duyệt (vượt quyền)

class ApprovalLevel(str, Enum):
    SALES_REP = "SALES_REP"                 # Nhân viên tự quyết
    SALES_MANAGER = "SALES_MANAGER"         # Trưởng phòng kinh doanh duyệt
    BOD = "BOD"                             # Ban Giám đốc duyệt

@dataclass
class RequestedItem:
    sku: Optional[str]
    name: str
    quantity: Optional[int]
    matched_sku: Optional[str] = None
    matched_name: Optional[str] = None
    unit_price_vnd: float = 0.0
    stock_available: int = 0
    is_stock_sufficient: bool = False
    item_lead_time_days: int = 0
    total_line_amount: float = 0.0

@dataclass
class CustomerRequest:
    id: str
    customer_name: str
    contact_person: Optional[str]
    contact_email: Optional[str]
    contact_phone: Optional[str]
    tier: str
    raw_request_text: str
    test_category: Optional[str] = None
    description: Optional[str] = None

@dataclass
class ExtractionResult:
    request_id: str
    customer_name: str
    contact_person: Optional[str]
    contact_email: Optional[str]
    contact_phone: Optional[str]
    tier: str
    items: List[RequestedItem]
    stated_budget_vnd: Optional[float]
    requested_deadline_days: Optional[int]
    requested_discount_pct: Optional[float]
    missing_fields: List[str]
    has_critical_missing_info: bool

@dataclass
class InventoryCheckResult:
    is_fully_stocked: bool
    stock_details: List[Dict[str, Any]]
    min_required_lead_time_days: int
    is_deadline_feasible: bool
    deadline_risk_note: Optional[str]

@dataclass
class PricingCheckResult:
    gross_total_vnd: float
    standard_tier_discount_pct: float
    volume_discount_pct: float
    policy_approved_discount_pct: float
    requested_discount_pct: float
    effective_discount_pct: float
    extra_discount_pct: float
    discount_amount_vnd: float
    net_total_vnd: float
    budget_comparison: str  # WITHIN_BUDGET, BUDGET_SHORTFALL, NO_BUDGET_GIVEN
    budget_variance_vnd: float
    budget_variance_pct: float
    required_approval_level: ApprovalLevel
    escalation_reasons: List[str]

@dataclass
class OpportunityDossier:
    opportunity_id: str
    request_id: str
    customer_name: str
    contact_person: str
    contact_email: str
    contact_phone: str
    customer_tier: str
    status: OpportunityStatus
    items_summary: List[Dict[str, Any]]
    gross_total_vnd: float
    net_total_vnd: float
    discount_pct: float
    stated_budget_vnd: Optional[float]
    feasible_lead_time_days: int
    requested_deadline_days: Optional[int]
    is_stock_sufficient: bool
    is_deadline_feasible: bool
    approval_level: ApprovalLevel
    escalation_reasons: List[str]
    missing_fields: List[str]
    next_action: str
    basis_of_decision: str

@dataclass
class ApprovalTicket:
    ticket_id: str
    opportunity_id: str
    request_id: str
    customer_name: str
    target_approver: ApprovalLevel
    order_gross_value: float
    order_net_value: float
    discount_requested_pct: float
    policy_standard_discount_pct: float
    extra_discount_pct: float
    escalation_reasons: List[str]
    lead_time_note: str
    inventory_note: str
    budget_note: str
    recommendation: str

@dataclass
class DraftEmail:
    email_id: str
    opportunity_id: str
    recipient_email: str
    recipient_name: str
    subject: str
    body: str
    email_type: str  # QUOTATION_PROPOSAL, CLARIFICATION_REQUEST, REJECTION_OR_ALTERNATIVE

