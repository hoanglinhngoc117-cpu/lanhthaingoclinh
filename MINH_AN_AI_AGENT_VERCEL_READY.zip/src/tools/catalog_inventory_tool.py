from typing import List, Dict, Any, Tuple
from src.models import RequestedItem, InventoryCheckResult

class CatalogInventoryTool:
    """
    Kỹ năng nghiệp vụ 2: Tra cứu danh mục sản phẩm, đối chiếu tồn kho khả dụng,
    và tính toán thời gian triển khai (Lead Time) khả thi.
    """
    def __init__(self, catalog_items: List[Dict[str, Any]]):
        self.catalog_map = {item["sku"]: item for item in catalog_items}

    def execute(self, items: List[RequestedItem], requested_deadline_days: int = None) -> Tuple[List[RequestedItem], InventoryCheckResult]:
        is_fully_stocked = True
        stock_details = []
        max_required_lead_time = 0

        for item in items:
            cat_info = self.catalog_map.get(item.sku)
            if not cat_info:
                # Không tìm thấy trong catalog
                item.unit_price_vnd = 0.0
                item.stock_available = 0
                item.is_stock_sufficient = False
                item.item_lead_time_days = 999
                item.total_line_amount = 0.0
                is_fully_stocked = False
                stock_details.append({
                    "sku": item.sku or "UNKNOWN",
                    "name": item.name,
                    "requested_qty": item.quantity or 0,
                    "available_stock": 0,
                    "status": "NOT_IN_CATALOG",
                    "lead_time_days": 999
                })
                continue

            # Sử dụng đúng bảng giá niêm yết hiện hành mới nhất
            item.matched_sku = cat_info["sku"]
            item.matched_name = cat_info["name"]
            item.unit_price_vnd = float(cat_info["unit_price_vnd"])
            item.stock_available = int(cat_info["available_stock"])
            
            qty = item.quantity or 0
            item.total_line_amount = item.unit_price_vnd * qty

            # Kiểm tra tồn kho khả dụng
            if qty <= item.stock_available:
                item.is_stock_sufficient = True
                item.item_lead_time_days = int(cat_info["standard_lead_time_days"])
                status = "IN_STOCK"
            else:
                item.is_stock_sufficient = False
                item.item_lead_time_days = int(cat_info["out_of_stock_lead_time_days"])
                is_fully_stocked = False
                status = "STOCK_DEFICIT"

            if item.item_lead_time_days > max_required_lead_time:
                max_required_lead_time = item.item_lead_time_days

            stock_details.append({
                "sku": cat_info["sku"],
                "name": cat_info["name"],
                "requested_qty": qty,
                "available_stock": item.stock_available,
                "status": status,
                "lead_time_days": item.item_lead_time_days
            })

        # Đánh giá khả năng đáp ứng thời hạn cam kết
        is_deadline_feasible = True
        deadline_risk_note = None

        if requested_deadline_days is not None:
            if requested_deadline_days < max_required_lead_time:
                is_deadline_feasible = False
                deadline_risk_note = (
                    f"RỦI RO TIẾN ĐỘ: Khách hàng yêu cầu giao trong {requested_deadline_days} ngày, "
                    f"nhưng thời gian tối thiểu để chuẩn bị và triển khai là {max_required_lead_time} ngày "
                    f"({'do một số mặt hàng hết kho cần nhập thêm' if not is_fully_stocked else 'theo quy trình kỹ thuật chuẩn'})."
                )
            else:
                deadline_risk_note = (
                    f"Tiến độ khả thi: Thời hạn khách yêu cầu {requested_deadline_days} ngày "
                    f">= Lead time tối thiểu {max_required_lead_time} ngày."
                )

        check_result = InventoryCheckResult(
            is_fully_stocked=is_fully_stocked,
            stock_details=stock_details,
            min_required_lead_time_days=max_required_lead_time,
            is_deadline_feasible=is_deadline_feasible,
            deadline_risk_note=deadline_risk_note
        )

        return items, check_result

