import re
from typing import List, Dict, Any, Optional
from src.models import RequestedItem, ExtractionResult, CustomerRequest

class ExtractionTool:
    """
    Kỹ năng nghiệp vụ 1: Trích xuất thực thể, chuẩn hóa dữ liệu văn bản
    và phát hiện thông tin còn thiếu từ yêu cầu khách hàng.
    """
    def __init__(self, catalog_items: List[Dict[str, Any]]):
        self.catalog_items = catalog_items

    def execute(self, request: CustomerRequest) -> ExtractionResult:
        text = request.raw_request_text
        text_lower = text.lower()
        items: List[RequestedItem] = []
        missing_fields: List[str] = []

        # Danh mục đối sánh từ khóa sản phẩm
        # Chú ý: Tách riêng từ khóa nhận diện và bảo vệ model number để không bị nhận nhầm thành số lượng
        product_keyword_map = [
            ("SRV-DELL-R750", ["dell poweredge r750", "dell r750", "poweredge r750", "máy chủ dell"]),
            ("SRV-HPE-DL380", ["hpe proliant dl380", "proliant dl380", "hpe dl380", "máy chủ hpe"]),
            ("SW-CISCO-C9200L", ["cisco catalyst 9200l", "catalyst 9200l", "c9200l", "cisco 9200", "thiết bị chuyển mạch cisco", "switch cisco"]),
            ("FW-FORTINET-60F", ["fortigate 60f", "fortinet 60f", "tường lửa fortinet"]),
            ("AP-ARUBA-AP505", ["aruba instant on ap505", "aruba ap505", "aruba ap-505", "bộ phát wifi aruba", "wifi aruba"]),
            ("SAN-SYNOLOGY-RS2423", ["synology rackstation rs2423", "synology rs2423+", "synology rs2423", "nas synology", "rs2423"]),
            ("SVC-DEPLOY-BASIC", ["dịch vụ lắp đặt, cấu hình", "dịch vụ lắp đặt triển khai", "dịch vụ lắp đặt", "triển khai cơ bản", "lắp đặt triển khai"]),
            ("SVC-MAINTAIN-1Y", ["gói bảo trì định kỳ", "bảo trì định kỳ", "bảo trì 1 năm", "gói bảo trì"])
        ]

        # Quét từng sản phẩm
        for sku, keywords in product_keyword_map:
            for kw in keywords:
                if kw in text_lower:
                    qty = self._extract_quantity(text, kw, sku)
                    cat_item = next((c for c in self.catalog_items if c["sku"] == sku), None)
                    item_name = cat_item["name"] if cat_item else kw
                    
                    if not any(it.sku == sku for it in items):
                        items.append(RequestedItem(
                            sku=sku,
                            name=item_name,
                            quantity=qty,
                            matched_sku=sku,
                            matched_name=item_name
                        ))
                    break

        # Nếu không trích xuất được sản phẩm nào cụ thể từ catalog
        if not items:
            if "máy chủ" in text_lower or "lưu trữ" in text_lower or "thiết bị" in text_lower or "bộ phát" in text_lower or "switch" in text_lower:
                items.append(RequestedItem(
                    sku=None,
                    name="Thiết bị CNTT chưa rõ chủng loại / model",
                    quantity=None
                ))

        # Kiểm tra sản phẩm có bị thiếu số lượng không
        for it in items:
            if it.quantity is None:
                missing_fields.append(f"Số lượng cho hạng mục '{it.name}'")

        if not items:
            missing_fields.append("Danh mục sản phẩm hoặc dịch vụ cụ thể")

        # 2. Trích xuất ngân sách
        stated_budget = self._extract_budget(text)
        if stated_budget is None:
            missing_fields.append("Tổng ngân sách dự kiến của khách hàng")

        # 3. Trích xuất thời hạn triển khai
        deadline_days = self._extract_deadline_days(text)
        if deadline_days is None:
            missing_fields.append("Thời hạn triển khai / bàn giao mong muốn")

        # 4. Trích xuất chiết khấu
        requested_discount = self._extract_discount_pct(text)

        # 5. Kiểm tra thông tin liên hệ / người quyết định
        if not request.contact_person or len(request.contact_person.strip()) < 2:
            missing_fields.append("Người đại diện liên hệ / Người có thẩm quyền phê duyệt")
        if not request.contact_email and not request.contact_phone:
            missing_fields.append("Thông tin liên lạc (Email hoặc Số điện thoại người nhận báo giá)")

        has_critical = len(missing_fields) > 0

        return ExtractionResult(
            request_id=request.id,
            customer_name=request.customer_name,
            contact_person=request.contact_person,
            contact_email=request.contact_email,
            contact_phone=request.contact_phone,
            tier=request.tier,
            items=items,
            stated_budget_vnd=stated_budget,
            requested_deadline_days=deadline_days,
            requested_discount_pct=requested_discount,
            missing_fields=missing_fields,
            has_critical_missing_info=has_critical
        )

    def _extract_quantity(self, text: str, keyword: str, sku: str) -> Optional[int]:
        # Nếu là gói dịch vụ, mặc định 1 gói nếu được đề cập
        if sku.startswith("SVC-"):
            # Kiểm tra xem có ghi rõ số lượng không
            m_svc = re.search(r"(\d+)\s*(?:gói|hợp đồng|năm)", text, re.IGNORECASE)
            return int(m_svc.group(1)) if m_svc else 1

        # Mẫu 1: Số lượng có từ chỉ đơn vị ngay trước hoặc liên kết với sản phẩm: "02 Máy chủ Dell", "4 Thiết bị chuyển mạch", "03 máy chủ HPE", "08 Máy chủ Dell", "09 Máy chủ"
        # Bắt: (0?[1-9]\d?)\s*(?:chiếc|bộ|cái|máy|thiết bị)?\s*(?:chủ|chuyển mạch|phát)?\s*keyword
        pattern1 = rf"\b(0?[1-9]\d?)\s+(?:chiếc|bộ|cái|máy chủ|máy|thiết bị chuyển mạch|thiết bị|bộ phát|tường lửa)?\s*.*?(?:{re.escape(keyword)})"
        m1 = re.search(pattern1, text, re.IGNORECASE)
        if m1:
            try:
                val = int(m1.group(1))
                # Tránh nhầm lẫn với các số model (60, 505, 380, 750, 9200)
                if val not in [60, 505, 380, 750, 9200, 2423]:
                    return val
            except ValueError:
                pass

        # Mẫu 2: "SL: 2", "số lượng 02", "số lượng: 5"
        pattern2 = rf"(?:{re.escape(keyword)}).*?(?:số lượng|sl|qty|quantity)\s*[:=]?\s*(\d+)"
        m2 = re.search(pattern2, text, re.IGNORECASE)
        if m2:
            try:
                return int(m2.group(1))
            except ValueError:
                pass

        # Mẫu 3: "báo giá 02 Máy chủ..." hoặc "cần mua 03 máy chủ..."
        pattern3 = rf"(?:báo giá|mua|cần|đặt mua|trang bị)\s+(0?[1-9]\d?)\s+(?:chiếc|bộ|cái|máy|thiết bị)?\s*.*?(?:{re.escape(keyword)})"
        m3 = re.search(pattern3, text, re.IGNORECASE)
        if m3:
            try:
                val = int(m3.group(1))
                if val not in [60, 505, 380, 750, 9200, 2423]:
                    return val
            except ValueError:
                pass

        return None

    def _extract_budget(self, text: str) -> Optional[float]:
        # Tỷ: "1,1 tỷ", "1.1 tỷ", "1 tỷ"
        m_ty = re.search(r"(\d+(?:[\.,]\d+)?)\s*(?:tỷ|ty)", text, re.IGNORECASE)
        if m_ty:
            val_str = m_ty.group(1).replace(",", ".")
            return float(val_str) * 1_000_000_000

        # Triệu: "420 triệu", "320 triệu"
        m_tr = re.search(r"(\d+(?:[\.,]\d+)?)\s*(?:triệu|trieu|tr\b)", text, re.IGNORECASE)
        if m_tr:
            val_str = m_tr.group(1).replace(",", ".")
            return float(val_str) * 1_000_000

        # Mẫu số đầy đủ: "420.000.000 VNĐ" hoặc "1.000.000.000 VNĐ"
        m_num = re.search(r"(\d{1,3}(?:\.\d{3}){2,3})\s*(?:vnđ|vnd|đ|đồng)?", text, re.IGNORECASE)
        if m_num:
            raw = m_num.group(1).replace(".", "")
            return float(raw)

        return None

    def _extract_deadline_days(self, text: str) -> Optional[int]:
        m_hour = re.search(r"(\d+)\s*(?:giờ|h|tiếng)", text, re.IGNORECASE)
        if m_hour:
            hours = int(m_hour.group(1))
            return max(1, round(hours / 24))

        m_day = re.search(r"(\d+)\s*ngày", text, re.IGNORECASE)
        if m_day:
            return int(m_day.group(1))

        m_week = re.search(r"(\d+)\s*tuần", text, re.IGNORECASE)
        if m_week:
            return int(m_week.group(1)) * 7

        return None

    def _extract_discount_pct(self, text: str) -> float:
        m_disc = re.search(r"(?:chiết khấu|giảm giá|discount)[^\d]{0,25}(\d+(?:[\.,]\d+)?)\s*%", text, re.IGNORECASE)
        if m_disc:
            val = m_disc.group(1).replace(",", ".")
            return float(val)
        return 0.0
