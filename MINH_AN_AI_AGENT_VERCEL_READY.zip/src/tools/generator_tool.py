import json
from pathlib import Path
from typing import Dict, Any, List
from src.models import (
    OpportunityDossier, ApprovalTicket, DraftEmail, OpportunityStatus, 
    ApprovalLevel, ExtractionResult, InventoryCheckResult, PricingCheckResult
)
from src.config import DOSSIERS_DIR, DRAFT_EMAILS_DIR, APPROVAL_TICKETS_DIR

class GeneratorTool:
    """
    Kỹ năng nghiệp vụ 4: Tạo hồ sơ cơ hội kinh doanh (Opportunity Dossier),
    bản nháp email phản hồi khách hàng (Draft Email) và phiếu chuyển duyệt (Approval Ticket).
    """
    def __init__(self, dossiers_dir: Path = DOSSIERS_DIR, 
                 emails_dir: Path = DRAFT_EMAILS_DIR, 
                 tickets_dir: Path = APPROVAL_TICKETS_DIR):
        self.dossiers_dir = dossiers_dir
        self.emails_dir = emails_dir
        self.tickets_dir = tickets_dir

    def generate_dossier(self, 
                         opp_id: str,
                         extraction: ExtractionResult, 
                         inventory: InventoryCheckResult, 
                         pricing: PricingCheckResult,
                         status: OpportunityStatus,
                         basis_of_decision: str,
                         next_action: str) -> OpportunityDossier:
        
        items_summary = []
        for it in extraction.items:
            items_summary.append({
                "sku": it.matched_sku or it.sku,
                "name": it.matched_name or it.name,
                "quantity": it.quantity,
                "unit_price_vnd": it.unit_price_vnd,
                "total_line_amount": it.total_line_amount,
                "stock_available": it.stock_available,
                "is_sufficient": it.is_stock_sufficient,
                "lead_time_days": it.item_lead_time_days
            })

        dossier = OpportunityDossier(
            opportunity_id=opp_id,
            request_id=extraction.request_id,
            customer_name=extraction.customer_name,
            contact_person=extraction.contact_person or "Chưa rõ",
            contact_email=extraction.contact_email or "Chưa rõ",
            contact_phone=extraction.contact_phone or "Chưa rõ",
            customer_tier=extraction.tier,
            status=status,
            items_summary=items_summary,
            gross_total_vnd=pricing.gross_total_vnd,
            net_total_vnd=pricing.net_total_vnd,
            discount_pct=pricing.effective_discount_pct,
            stated_budget_vnd=extraction.stated_budget_vnd,
            feasible_lead_time_days=inventory.min_required_lead_time_days,
            requested_deadline_days=extraction.requested_deadline_days,
            is_stock_sufficient=inventory.is_fully_stocked,
            is_deadline_feasible=inventory.is_deadline_feasible,
            approval_level=pricing.required_approval_level,
            escalation_reasons=pricing.escalation_reasons,
            missing_fields=extraction.missing_fields,
            next_action=next_action,
            basis_of_decision=basis_of_decision
        )

        # Lưu file Markdown hồ sơ cơ hội (nếu môi trường cho phép ghi)
        try:
            self.dossiers_dir.mkdir(parents=True, exist_ok=True)
            md_path = self.dossiers_dir / f"Dossier_{opp_id}.md"
            with open(md_path, "w", encoding="utf-8") as f:
                f.write(self._format_dossier_markdown(dossier))
        except OSError:
            pass

        return dossier

    def generate_draft_email(self, dossier: OpportunityDossier) -> DraftEmail:
        opp_id = dossier.opportunity_id
        customer_name = dossier.customer_name
        contact_person = dossier.contact_person if dossier.contact_person != "Chưa rõ" else "Quý khách hàng"
        status = dossier.status

        if status == OpportunityStatus.NEEDS_INFO:
            subject = f"[Minh An Technology] Xác nhận và xin bổ sung thông tin yêu cầu - {customer_name}"
            email_type = "CLARIFICATION_REQUEST"
            missing_list_str = "\n".join([f"  - {f}" for f in dossier.missing_fields])
            body = (
                f"Kính gửi {contact_person},\n"
                f"Đại diện {customer_name},\n\n"
                f"Công ty Minh An xin chân thành cảm ơn Quý công ty đã quan tâm đến thiết bị và dịch vụ giải pháp CNTT của chúng tôi.\n\n"
                f"Để có thể lập Bảng chào giá chính xác nhất cùng cam kết tiến độ tối ưu cho Quý đơn vị, chúng tôi kính đề nghị Quý khách hỗ trợ làm rõ một số nội dung sau:\n"
                f"{missing_list_str}\n\n"
                f"Ngay khi nhận được thông tin bổ sung, chuyên viên kinh doanh của Minh An sẽ gửi Đề xuất kỹ thuật - thương mại hoàn chỉnh trong vòng 04 giờ làm việc.\n\n"
                f"Trân trọng cảm ơn và kính chúc Quý công ty ngày càng phát triển!\n\n"
                f"---\n"
                f"Bộ phận Kinh doanh Doanh nghiệp (B2B)\n"
                f"Công ty Công nghệ Minh An\n"
                f"Hotline: 1900-8888 | Email: b2b@minhan-tech.vn"
            )

        elif status == OpportunityStatus.PENDING_APPROVAL:
            subject = f"[Minh An Technology] Đề xuất sơ bộ & Tiếp nhận hồ sơ chào giá - {customer_name}"
            email_type = "QUOTATION_PROPOSAL_PENDING_APPROVAL"
            items_str = "\n".join([
                f"  - {it['name']}: {it['quantity']} đơn vị (Tồn kho: {'Sẵn sàng' if it['is_sufficient'] else 'Đang điều phối'})"
                for it in dossier.items_summary
            ])
            body = (
                f"Kính gửi {contact_person},\n"
                f"Đại diện {customer_name},\n\n"
                f"Công ty Minh An trân trọng cảm ơn Quý khách đã gửi yêu cầu trang bị thiết bị công nghệ.\n\n"
                f"Chúng tôi đã tiếp nhận danh mục yêu cầu gồm:\n{items_str}\n\n"
                f"Hiện tại, đề xuất của Quý công ty có chính sách chiết khấu đặc biệt ({dossier.discount_pct:.1f}%) và quy mô lớn ({dossier.net_total_vnd:,.0f} VNĐ). "
                f"Hồ sơ đang được trình {dossier.approval_level.value} phê duyệt theo quy chế thẩm quyền để đảm bảo mức ưu đãi tốt nhất cho Quý công ty.\n\n"
                f"Dự kiến phản hồi chính thức kèm Báo giá có dấu xác nhận sẽ gửi tới Quý khách trước 17h00 cùng ngày.\n\n"
                f"Trân trọng cảm ơn sự hợp tác của Quý khách!\n\n"
                f"---\n"
                f"Bộ phận Kinh doanh Doanh nghiệp (B2B)\n"
                f"Công ty Công nghệ Minh An"
            )

        elif status == OpportunityStatus.CANNOT_FULFILL:
            subject = f"[Minh An Technology] Phản hồi yêu cầu giải pháp & Đề xuất phương án thay thế - {customer_name}"
            email_type = "REJECTION_OR_ALTERNATIVE"
            body = (
                f"Kính gửi {contact_person},\n"
                f"Đại diện {customer_name},\n\n"
                f"Công ty Minh An trân trọng cảm ơn sự tin tưởng của Quý khách.\n\n"
                f"Qua rà soát năng lực cung ứng hiện tại, chúng tôi nhận thấy thời hạn yêu cầu ({dossier.requested_deadline_days} ngày) "
                f"ngắn hơn thời gian quy chuẩn an toàn kỹ thuật của Minh An ({dossier.feasible_lead_time_days} ngày) để đảm bảo kiểm thử và cài đặt hệ thống.\n\n"
                f"Để không ảnh hưởng đến hoạt động của Quý đơn vị, Minh An xin đề xuất:\n"
                f"1. Bàn giao thiết bị trước theo giai đoạn 1, hoặc\n"
                f"2. Thay thế bằng cấu hình tương đương có sẵn tại kho có thể giao hỏa tốc.\n\n"
                f"Chuyên viên của chúng tôi sẽ gọi điện trao đổi trực tiếp trong ít phút tới.\n\n"
                f"Trân trọng cảm ơn,\n"
                f"---\n"
                f"Bộ phận Kinh doanh Doanh nghiệp (B2B)\n"
                f"Công ty Công nghệ Minh An"
            )

        else: # CAN_PROCEED
            subject = f"[Minh An Technology] Báo giá chính thức & Kế hoạch triển khai - {customer_name}"
            email_type = "QUOTATION_PROPOSAL"
            items_str = "\n".join([
                f"  - {it['name']} | SL: {it['quantity']} | Đơn giá: {it['unit_price_vnd']:,.0f} VNĐ | Thành tiền: {it['total_line_amount']:,.0f} VNĐ"
                for it in dossier.items_summary
            ])
            body = (
                f"Kính gửi {contact_person},\n"
                f"Đại diện {customer_name},\n\n"
                f"Công ty Minh An xin trân trọng gửi tới Quý khách hàng bảng báo giá chính thức cho các hạng mục thiết bị và dịch vụ đã yêu cầu:\n\n"
                f"CHI TIẾT HẠNG MỤC:\n{items_str}\n\n"
                f"TỔNG KẾT THƯƠNG MẠI:\n"
                f"  * Tổng giá trị niêm yết: {dossier.gross_total_vnd:,.0f} VNĐ\n"
                f"  * Mức chiết khấu áp dụng ({dossier.discount_pct:.1f}%): -{(dossier.gross_total_vnd - dossier.net_total_vnd):,.0f} VNĐ\n"
                f"  * TỔNG GIÁ TRỊ THANH TOÁN (chưa VAT): {dossier.net_total_vnd:,.0f} VNĐ\n"
                f"  * Thời gian giao hàng & bàn giao: Trong vòng {dossier.feasible_lead_time_days} ngày làm việc kể từ khi ký hợp đồng.\n"
                f"  * Tình trạng hàng hóa: Có sẵn đầy đủ trong kho, mới 100%, bảo hành chính hãng.\n\n"
                f"Báo giá có hiệu lực trong vòng 15 ngày làm việc. Kính mong nhận được sự phản hồi từ Quý khách.\n\n"
                f"Trân trọng,\n"
                f"---\n"
                f"Bộ phận Kinh doanh Doanh nghiệp (B2B)\n"
                f"Công ty Công nghệ Minh An"
            )

        draft = DraftEmail(
            email_id=f"EMAIL-{opp_id}",
            opportunity_id=opp_id,
            recipient_email=dossier.contact_email,
            recipient_name=dossier.contact_person,
            subject=subject,
            body=body,
            email_type=email_type
        )

        try:
            self.emails_dir.mkdir(parents=True, exist_ok=True)
            email_path = self.emails_dir / f"Email_{opp_id}.txt"
            with open(email_path, "w", encoding="utf-8") as f:
                f.write(f"TO: {draft.recipient_email} ({draft.recipient_name})\n")
                f.write(f"SUBJECT: {draft.subject}\n")
                f.write(f"TYPE: {draft.email_type}\n")
                f.write("="*70 + "\n\n")
                f.write(draft.body)
        except OSError:
            pass

        return draft

    def generate_approval_ticket(self, dossier: OpportunityDossier, pricing: PricingCheckResult) -> ApprovalTicket:
        ticket_id = f"TICKET-{dossier.opportunity_id}"
        
        ticket = ApprovalTicket(
            ticket_id=ticket_id,
            opportunity_id=dossier.opportunity_id,
            request_id=dossier.request_id,
            customer_name=dossier.customer_name,
            target_approver=dossier.approval_level,
            order_gross_value=dossier.gross_total_vnd,
            order_net_value=dossier.net_total_vnd,
            discount_requested_pct=pricing.requested_discount_pct,
            policy_standard_discount_pct=pricing.policy_approved_discount_pct,
            extra_discount_pct=pricing.extra_discount_pct,
            escalation_reasons=dossier.escalation_reasons,
            lead_time_note=f"Lead time kỹ thuật: {dossier.feasible_lead_time_days} ngày (Khách yêu cầu: {dossier.requested_deadline_days or 'Chưa nêu'} ngày)",
            inventory_note="Đủ hàng tồn kho" if dossier.is_stock_sufficient else "THIẾU TỒN KHO - Cần nhập khẩn",
            budget_note=f"Ngân sách khách: {dossier.stated_budget_vnd:,.0f} VNĐ" if dossier.stated_budget_vnd else "Khách không công bố ngân sách",
            recommendation=f"Đề xuất {dossier.approval_level.value} xem xét phê duyệt chính sách thương mại để hỗ trợ chốt hợp đồng lớn với khách hàng {dossier.customer_name}."
        )

        try:
            self.tickets_dir.mkdir(parents=True, exist_ok=True)
            ticket_path = self.tickets_dir / f"Ticket_{ticket_id}.md"
            with open(ticket_path, "w", encoding="utf-8") as f:
                f.write(self._format_ticket_markdown(ticket))
        except OSError:
            pass

        return ticket

    def _format_dossier_markdown(self, d: OpportunityDossier) -> str:
        lines = [
            f"# HỒ SƠ CƠ HỘI BÁN HÀNG B2B - {d.opportunity_id}",
            f"**Mã yêu cầu gốc**: `{d.request_id}` | **Ngày xử lý**: 2026-11-11",
            f"**Khách hàng**: {d.customer_name} (Hạng: `{d.customer_tier}`)",
            f"**Đại diện liên hệ**: {d.contact_person} | **Email**: {d.contact_email} | **Điện thoại**: {d.contact_phone}",
            "",
            "## 1. TÌNH TRẠNG VÀ PHÂN LOẠI CƠ HỘI",
            f"- **Trạng thái xử lý**: `{d.status.value}`",
            f"- **Cấp thẩm quyền quyết định**: `{d.approval_level.value}`",
            f"- **Căn cứ quyết định**: {d.basis_of_decision}",
            f"- **Bước xử lý tiếp theo**: {d.next_action}",
            "",
            "## 2. KẾT QUẢ ĐỐI CHIẾU HẠNG MỤC & TỒN KHO",
            "| SKU | Tên Hạng Mục | SL Yêu Cầu | Đơn Giá (VNĐ) | Thành Tiền (VNĐ) | Tồn Kho | Trạng Thái Kho |",
            "| --- | --- | ---: | ---: | ---: | ---: | :---: |"
        ]
        for it in d.items_summary:
            status_kho = "✅ Sẵn sàng" if it["is_sufficient"] else "⚠️ Thiếu kho"
            lines.append(
                f"| `{it['sku']}` | {it['name']} | {it['quantity'] or 'N/A'} | "
                f"{it['unit_price_vnd']:,.0f} | {it['total_line_amount']:,.0f} | "
                f"{it['stock_available']} | {status_kho} |"
            )

        lines.extend([
            "",
            "## 3. PHÂN TÍCH TÀI CHÍNH & CHÍNH SÁCH THƯƠNG MẠI",
            f"- **Tổng giá trị niêm yết (Gross Total)**: `{d.gross_total_vnd:,.0f} VNĐ`",
            f"- **Chiết khấu áp dụng**: `{d.discount_pct:.1f}%`",
            f"- **Giá trị đề xuất thanh toán (Net Total)**: `{d.net_total_vnd:,.0f} VNĐ`",
            f"- **Ngân sách công bố của khách hàng**: `{f'{d.stated_budget_vnd:,.0f} VNĐ' if d.stated_budget_vnd else 'Không công bố'}`",
            "",
            "## 4. ĐÁNH GIÁ NĂNG LỰC ĐÁP ỨNG THỜI GIAN",
            f"- **Thời hạn khách yêu cầu**: `{f'{d.requested_deadline_days} ngày' if d.requested_deadline_days else 'Không nêu'}`",
            f"- **Thời gian đáp ứng tối thiểu của Minh An**: `{d.feasible_lead_time_days} ngày`",
            f"- **Kết luận tiến độ**: {'✅ Đáp ứng tốt' if d.is_deadline_feasible else '❌ Cảnh báo rủi ro tiến độ'}",
            ""
        ])

        if d.escalation_reasons:
            lines.append("## 5. LÝ DO CHUYỂN DUYỆT (ESCALATION REASONS)")
            for r in d.escalation_reasons:
                lines.append(f"- ⚠️ {r}")
            lines.append("")

        if d.missing_fields:
            lines.append("## 6. THÔNG TIN CÒN THIẾU CẦN KHÁCH HÀNG BỔ SUNG")
            for m in d.missing_fields:
                lines.append(f"- ❓ {m}")
            lines.append("")

        lines.append("---")
        lines.append("*Hồ sơ được tạo tự động bởi AI Agent Minh An - Đã lưu vết Audit Trail đầy đủ.*")
        return "\n".join(lines)

    def _format_ticket_markdown(self, t: ApprovalTicket) -> str:
        lines = [
            f"# PHIẾU CHUYỂN DUYỆT CƠ HỘI BÁN HÀNG VƯỢT THẨM QUYỀN",
            f"**Mã Phiếu**: `{t.ticket_id}` | **Mã Hồ sơ**: `{t.opportunity_id}`",
            f"**Kính gửi**: `{t.target_approver.value}`",
            f"**Khách hàng**: {t.customer_name}",
            "",
            "## 1. THÔNG SỐ ĐỀ XUẤT THƯƠNG MẠI",
            f"- **Tổng giá trị niêm yết**: `{t.order_gross_value:,.0f} VNĐ`",
            f"- **Tổng giá trị đề xuất sau chiết khấu**: `{t.order_net_value:,.0f} VNĐ`",
            f"- **Mức chiết khấu khách đề nghị**: `{t.discount_requested_pct:.1f}%`",
            f"- **Mức chiết khấu định mức tiêu chuẩn**: `{t.policy_standard_discount_pct:.1f}%`",
            f"- **Mức chiết khấu vượt thẩm quyền Sales**: `{t.extra_discount_pct:.1f}%`",
            "",
            "## 2. NĂNG LỰC CUNG ỨNG & NGÂN SÁCH",
            f"- **Tình trạng hàng hóa**: {t.inventory_note}",
            f"- **Tiến độ triển khai**: {t.lead_time_note}",
            f"- **Khả năng chi trả**: {t.budget_note}",
            "",
            "## 3. CĂN CỨ VÀ LÝ DO CHUYỂN CẤP DUYỆT"
        ]
        for r in t.escalation_reasons:
            lines.append(f"- 🔴 **{r}**")
        
        lines.extend([
            "",
            "## 4. ĐỀ XUẤT CỦA BỘ PHẬN KINH DOANH",
            f"{t.recommendation}",
            "",
            "---",
            "**Ý KIẾN CỦA CẤP PHÊ DUYỆT:**",
            "[  ] ĐỒNG Ý PHÊ DUYỆT THEO ĐỀ XUẤT",
            "[  ] YÊU CẦU ĐÀM PHÁN LẠI VỚI KHÁCH HÀNG (Ghi chú lý do)",
            "[  ] TỪ CHỐI",
            "",
            "Chữ ký / Xác thực điện tử: ....................................... Ngày: ...../...../2026"
        ])
        return "\n".join(lines)

