from typing import List, Dict, Any, Optional
from src.models import RequestedItem, PricingCheckResult, ApprovalLevel, InventoryCheckResult

class PricingPolicyTool:
    """
    Kỹ năng nghiệp vụ 3: Tính toán giá trị đề xuất, áp dụng chính sách chiết khấu,
    đối chiếu ngân sách và kiểm tra ma trận phân quyền chuyển duyệt.
    """
    def __init__(self, discount_policy: Dict[str, Any], approval_matrix: Dict[str, Any]):
        self.discount_policy = discount_policy
        self.approval_matrix = approval_matrix

    def execute(self, 
                customer_tier: str, 
                items: List[RequestedItem], 
                stated_budget_vnd: Optional[float], 
                requested_discount_pct: float,
                inventory_result: InventoryCheckResult) -> PricingCheckResult:
        
        # 1. Tính tổng giá trị niêm yết (Gross Total)
        gross_total = sum(item.total_line_amount for item in items)

        # 2. Xác định chiết khấu theo phân hạng khách hàng
        tier_info = self.discount_policy.get("customer_tiers", {}).get(customer_tier.upper(), {})
        tier_discount = float(tier_info.get("base_discount_pct", 0.0))

        # 3. Xác định chiết khấu theo quy mô đơn hàng (Volume Discount)
        volume_discount = 0.0
        for threshold in self.discount_policy.get("volume_discount_thresholds", []):
            if threshold["min_order_value_vnd"] <= gross_total < threshold["max_order_value_vnd"]:
                volume_discount = float(threshold["volume_discount_pct"])
                break

        # Chiết khấu chuẩn theo chính sách công ty
        policy_discount = tier_discount + volume_discount
        max_allowable_cap = float(self.discount_policy.get("max_allowable_discount_pct", 18.0))

        # 4. Xác định chiết khấu đề xuất áp dụng (Effective discount)
        # Nếu khách yêu cầu cao hơn policy, cần tính phần vượt (extra discount)
        req_disc = requested_discount_pct or 0.0
        if req_disc > policy_discount:
            effective_discount = min(req_disc, max_allowable_cap)
            extra_discount = effective_discount - policy_discount
        else:
            effective_discount = policy_discount
            extra_discount = 0.0

        discount_amount = gross_total * (effective_discount / 100.0)
        net_total = gross_total - discount_amount

        # 5. Đối chiếu ngân sách của khách hàng
        budget_comparison = "NO_BUDGET_GIVEN"
        budget_variance_vnd = 0.0
        budget_variance_pct = 0.0

        if stated_budget_vnd is not None and stated_budget_vnd > 0:
            budget_variance_vnd = stated_budget_vnd - net_total
            budget_variance_pct = (budget_variance_vnd / net_total) * 100.0
            if budget_variance_vnd >= 0:
                budget_comparison = "WITHIN_BUDGET"
            else:
                budget_comparison = "BUDGET_SHORTFALL"

        # 6. Kiểm tra ma trận phân quyền phê duyệt (Approval Matrix)
        escalation_reasons: List[str] = []
        required_level = ApprovalLevel.SALES_REP

        # Điều kiện 1: Mức chiết khấu vượt thẩm quyền
        # Sales Rep chỉ được duyệt extra <= 3%
        if extra_discount > 10.0 or effective_discount > 12.0:
            required_level = ApprovalLevel.BOD
            escalation_reasons.append(f"Mức chiết khấu đề nghị ({effective_discount:.1f}%, vượt định mức {extra_discount:.1f}%) thuộc thẩm quyền phê duyệt của Ban Giám đốc")
        elif extra_discount > 3.0:
            required_level = self._elevate_level(required_level, ApprovalLevel.SALES_MANAGER)
            escalation_reasons.append(f"Mức chiết khấu vượt định mức chuẩn {extra_discount:.1f}% (> 3%) cần Trưởng phòng Kinh doanh duyệt")

        # Điều kiện 2: Tổng giá trị đơn hàng
        # Sales Rep <= 200M; Sales Manager <= 500M; BOD > 500M
        if net_total >= 500000000:
            required_level = ApprovalLevel.BOD
            escalation_reasons.append(f"Tổng giá trị đơn hàng ({net_total:,.0f} VNĐ >= 500M) cần Ban Giám đốc phê duyệt")
        elif net_total > 200000000:
            required_level = self._elevate_level(required_level, ApprovalLevel.SALES_MANAGER)
            escalation_reasons.append(f"Tổng giá trị đơn hàng ({net_total:,.0f} VNĐ > 200M) vượt thẩm quyền tự quyết của Sales Rep")

        # Điều kiện 3: Tồn kho thiếu hụt
        if not inventory_result.is_fully_stocked:
            required_level = self._elevate_level(required_level, ApprovalLevel.SALES_MANAGER)
            escalation_reasons.append("Tồn kho hiện tại không đủ đáp ứng toàn bộ số lượng yêu cầu, cần ý kiến Trưởng phòng & Vận hành")

        # Điều kiện 4: Rủi ro thời hạn (Deadline gấp hơn SLA)
        if not inventory_result.is_deadline_feasible:
            required_level = self._elevate_level(required_level, ApprovalLevel.SALES_MANAGER)
            escalation_reasons.append(inventory_result.deadline_risk_note or "Thời hạn yêu cầu ngắn hơn thời gian đáp ứng tối thiểu")

        # Điều kiện 5: Ngân sách khách hàng thiếu hụt (Budget shortfall)
        if budget_comparison == "BUDGET_SHORTFALL":
            deficit_pct = abs(budget_variance_pct)
            if deficit_pct > 15.0:
                required_level = self._elevate_level(required_level, ApprovalLevel.SALES_MANAGER)
                escalation_reasons.append(f"Ngân sách khách hàng thiếu hụt {deficit_pct:.1f}% so với giá trị đề xuất sau chiết khấu")

        return PricingCheckResult(
            gross_total_vnd=gross_total,
            standard_tier_discount_pct=tier_discount,
            volume_discount_pct=volume_discount,
            policy_approved_discount_pct=policy_discount,
            requested_discount_pct=req_disc,
            effective_discount_pct=effective_discount,
            extra_discount_pct=extra_discount,
            discount_amount_vnd=discount_amount,
            net_total_vnd=net_total,
            budget_comparison=budget_comparison,
            budget_variance_vnd=budget_variance_vnd,
            budget_variance_pct=budget_variance_pct,
            required_approval_level=required_level,
            escalation_reasons=escalation_reasons
        )

    def _elevate_level(self, current: ApprovalLevel, target: ApprovalLevel) -> ApprovalLevel:
        ranks = {ApprovalLevel.SALES_REP: 1, ApprovalLevel.SALES_MANAGER: 2, ApprovalLevel.BOD: 3}
        if ranks[target] > ranks[current]:
            return target
        return current

