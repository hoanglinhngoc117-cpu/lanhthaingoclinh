# ==============================================================================
# HỆ THỐNG WEB SERVER LOCALHOST - MINH AN TECH AI AGENT B2B
# Cung cấp giao diện Web Dashboard trên http://localhost:8088
# ==============================================================================

param(
    [int]$Port = 8088
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$BaseDir = Resolve-Path (Join-Path $PSScriptRoot "..")
$WebDir = Join-Path $BaseDir "web"
$DataDir = Join-Path $BaseDir "data"
$OutputDir = Join-Path $BaseDir "output"
$DossiersDir = Join-Path $OutputDir "dossiers"
$DraftEmailsDir = Join-Path $OutputDir "draft_emails"
$ApprovalTicketsDir = Join-Path $OutputDir "approval_tickets"
$LogsDir = Join-Path $OutputDir "logs"
$AuditLogFile = Join-Path $LogsDir "execution_audit.log"

$CatalogPath = Join-Path $DataDir "products_catalog.json"
$DiscountPolicyPath = Join-Path $DataDir "discount_policy.json"
$ApprovalMatrixPath = Join-Path $DataDir "approval_matrix.json"
$SampleRequestsPath = Join-Path $DataDir "sample_requests.json"
$DashboardPath = Join-Path $OutputDir "summary_dashboard.json"

# Load Rules
$Catalog = Get-Content $CatalogPath -Raw -Encoding UTF8 | ConvertFrom-Json
$DiscountPolicy = Get-Content $DiscountPolicyPath -Raw -Encoding UTF8 | ConvertFrom-Json
$ApprovalMatrix = Get-Content $ApprovalMatrixPath -Raw -Encoding UTF8 | ConvertFrom-Json

$listener = New-Object System.Net.HttpListener
$prefix = "http://localhost:$Port/"
$listener.Prefixes.Add($prefix)

try {
    $listener.Start()
    Write-Host "================================================================================" -ForegroundColor Cyan
    Write-Host " [MINH AN AI AGENT] WEB SERVER DANG CHAY TAI:" -ForegroundColor Green
    Write-Host " >>> $prefix" -ForegroundColor Yellow
    Write-Host " Nhan Ctrl+C de dung server." -ForegroundColor Gray
    Write-Host "================================================================================" -ForegroundColor Cyan
} catch {
    Write-Host "[ERROR] Khong the mo port $Port : $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

function Send-Response {
    param($context, [string]$content, [string]$contentType = "text/html; charset=utf-8", [int]$statusCode = 200)
    $buffer = [System.Text.Encoding]::UTF8.GetBytes($content)
    $context.Response.StatusCode = $statusCode
    $context.Response.ContentType = $contentType
    $context.Response.ContentLength64 = $buffer.Length
    $context.Response.AddHeader("Access-Control-Allow-Origin", "*")
    $context.Response.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    $context.Response.AddHeader("Access-Control-Allow-Headers", "Content-Type")
    $context.Response.OutputStream.Write($buffer, 0, $buffer.Length)
    $context.Response.OutputStream.Close()
}

function Run-Agent-Single {
    param($reqJson)
    $reqText = $reqJson.raw_request_text
    $tier = if ($reqJson.tier) { $reqJson.tier } else { "STANDARD" }
    $custName = if ($reqJson.customer_name) { $reqJson.customer_name } else { "Khách Hàng Mới" }
    $contact = if ($reqJson.contact_person) { $reqJson.contact_person } else { "" }
    $email = if ($reqJson.contact_email) { $reqJson.contact_email } else { "" }

    $reqId = "REQ-LIVE-" + (Get-Date).ToString("mmss")
    $oppId = "OPP-" + (Get-Date).ToString("mmss")

    # Keyword mapping
    $kwMap = @(
        @{ SKU="SRV-DELL-R750"; KW=@("dell poweredge r750", "dell r750", "poweredge r750", "máy chủ dell") },
        @{ SKU="SRV-HPE-DL380"; KW=@("hpe proliant dl380", "proliant dl380", "hpe dl380", "máy chủ hpe") },
        @{ SKU="SW-CISCO-C9200L"; KW=@("cisco catalyst 9200l", "catalyst 9200l", "c9200l", "cisco 9200", "thiết bị chuyển mạch cisco", "switch cisco") },
        @{ SKU="FW-FORTINET-60F"; KW=@("fortigate 60f", "fortinet 60f", "tường lửa fortinet") },
        @{ SKU="AP-ARUBA-AP505"; KW=@("aruba instant on ap505", "aruba ap505", "aruba ap-505", "bộ phát wifi aruba", "wifi aruba") },
        @{ SKU="SAN-SYNOLOGY-RS2423"; KW=@("synology rackstation rs2423", "synology rs2423+", "synology rs2423", "nas synology", "rs2423") },
        @{ SKU="SVC-DEPLOY-BASIC"; KW=@("dịch vụ lắp đặt, cấu hình", "dịch vụ lắp đặt triển khai", "dịch vụ lắp đặt", "triển khai cơ bản", "lắp đặt triển khai") },
        @{ SKU="SVC-MAINTAIN-1Y"; KW=@("gói bảo trì định kỳ", "bảo trì định kỳ", "bảo trì 1 năm", "gói bảo trì") }
    )
    $modelNumbers = @(60, 505, 380, 750, 9200, 2423, 10)

    $items = @()
    $missingFields = @()

    foreach ($entry in $kwMap) {
        foreach ($kw in $entry.KW) {
            if ($reqText.ToLower().Contains($kw.ToLower())) {
                $sku = $entry.SKU
                $catItem = $Catalog | Where-Object { $_.sku -eq $sku } | Select-Object -First 1
                $qty = $null
                if ($sku -like "SVC-*") {
                    $qty = 1
                } else {
                    $p1 = "(?i)\b(0?[1-9]\d?)\s+(?:chiếc|bộ|cái|máy chủ|máy|thiết bị chuyển mạch|thiết bị|bộ phát|tường lửa)?\s*.*?" + [regex]::Escape($kw)
                    if ($reqText -match $p1) {
                        $candidate = [int]$matches[1]
                        if ($modelNumbers -notcontains $candidate) { $qty = $candidate }
                    }
                    if ($null -eq $qty) {
                        $p2 = "(?i)" + [regex]::Escape($kw) + ".*?(?:số lượng|sl|qty)\s*[:=]?\s*(\d+)"
                        if ($reqText -match $p2) {
                            $candidate = [int]$matches[1]
                            if ($modelNumbers -notcontains $candidate) { $qty = $candidate }
                        }
                    }
                    if ($null -eq $qty) {
                        $p3 = "(?i)(?:báo giá|mua|cần|đặt mua|trang bị)\s+(0?[1-9]\d?)\s+.*?" + [regex]::Escape($kw)
                        if ($reqText -match $p3) {
                            $candidate = [int]$matches[1]
                            if ($modelNumbers -notcontains $candidate) { $qty = $candidate }
                        }
                    }
                }
                if (-not ($items | Where-Object { $_.sku -eq $sku })) {
                    $items += [PSCustomObject]@{ sku=$sku; name=$catItem.name; quantity=$qty }
                }
                break
            }
        }
    }

    foreach ($it in $items) {
        if ($null -eq $it.quantity) { $missingFields += "Số lượng cho '$($it.name)'" }
    }
    if ($items.Count -eq 0) { $missingFields += "Danh mục sản phẩm/dịch vụ cụ thể" }

    # Budget
    $statedBudget = $null
    if ($reqText -match "(?i)(\d+(?:[\.,]\d+)?)\s*(?:tỷ|ty)") {
        $statedBudget = [double]($matches[1].Replace(",", ".")) * 1000000000
    } elseif ($reqText -match "(?i)(\d+(?:[\.,]\d+)?)\s*(?:triệu|trieu|tr\b)") {
        $statedBudget = [double]($matches[1].Replace(",", ".")) * 1000000
    } elseif ($reqText -match "(?i)(\d{1,3}(?:\.\d{3}){2,3})") {
        $statedBudget = [double]($matches[1].Replace(".", ""))
    }
    if ($null -eq $statedBudget) { $missingFields += "Tổng ngân sách dự kiến" }

    # Deadline
    $deadlineDays = $null
    if ($reqText -match "(?i)(\d+)\s*(?:giờ|h|tiếng)") {
        $deadlineDays = [Math]::Max(1, [int][Math]::Round([double]$matches[1] / 24))
    } elseif ($reqText -match "(?i)(\d+)\s*ngày") {
        $deadlineDays = [int]$matches[1]
    }
    if ($null -eq $deadlineDays) { $missingFields += "Thời hạn bàn giao" }

    # Discount
    $reqDiscount = 0.0
    if ($reqText -match "(?i)(?:chiết khấu|giảm giá|discount)[^\d]{0,25}(\d+(?:[\.,]\d+)?)\s*%") {
        $reqDiscount = [double]($matches[1].Replace(",", "."))
    }

    # Inventory & Pricing
    $isFullyStocked = $true
    $maxLead = 0
    $grossTotal = 0.0
    $detailedItems = @()

    foreach ($it in $items) {
        $catItem = $Catalog | Where-Object { $_.sku -eq $it.sku } | Select-Object -First 1
        $q = if ($it.quantity) { [int]$it.quantity } else { 0 }
        $price = if ($catItem) { [double]$catItem.unit_price_vnd } else { 0 }
        $stock = if ($catItem) { [int]$catItem.available_stock } else { 0 }
        $isSuff = ($q -le $stock)
        if (-not $isSuff) { $isFullyStocked = $false }
        $lead = if ($isSuff) { [int]$catItem.standard_lead_time_days } else { [int]$catItem.out_of_stock_lead_time_days }
        if ($lead -gt $maxLead) { $maxLead = $lead }
        $line = $price * $q
        $grossTotal += $line
        $detailedItems += [PSCustomObject]@{ sku=$it.sku; name=$it.name; quantity=$q; unit_price=$price; line_amount=$line; stock_available=$stock; is_sufficient=$isSuff; lead_time=$lead }
    }

    $tierKey = $tier.ToUpper()
    $tierDisc = if ($DiscountPolicy.customer_tiers.$tierKey) { [double]$DiscountPolicy.customer_tiers.$tierKey.base_discount_pct } else { 0.0 }
    $volDisc = 0.0
    foreach ($th in $DiscountPolicy.volume_discount_thresholds) {
        if ($grossTotal -ge [double]$th.min_order_value_vnd -and $grossTotal -lt [double]$th.max_order_value_vnd) {
            $volDisc = [double]$th.volume_discount_pct; break
        }
    }
    $policyDisc = $tierDisc + $volDisc
    $effectiveDisc = if ($reqDiscount -gt $policyDisc) { [Math]::Min($reqDiscount, [double]$DiscountPolicy.max_allowable_discount_pct) } else { $policyDisc }
    $extraDisc = $effectiveDisc - $policyDisc
    $netTotal = $grossTotal - ($grossTotal * ($effectiveDisc / 100.0))

    $level = "SALES_REP"
    $reasons = @()
    if ($extraDisc -gt 10.0 -or $effectiveDisc -gt 12.0) { $level = "BOD"; $reasons += "Chiết khấu ($effectiveDisc%) thuộc quyền BOD" }
    elseif ($extraDisc -gt 3.0) { if ($level -ne "BOD") { $level = "SALES_MANAGER" }; $reasons += "Chiết khấu vượt quyền Sales ($extraDisc% > 3%)" }

    if ($netTotal -ge 500000000) { $level = "BOD"; $reasons += "Đơn hàng ($([string]::Format('{0:N0}', $netTotal)) đ >= 500M) cần BOD duyệt" }
    elseif ($netTotal -gt 200000000) { if ($level -ne "BOD") { $level = "SALES_MANAGER" }; $reasons += "Đơn hàng > 200M vượt quyền Sales Rep" }

    if (-not $isFullyStocked) { if ($level -ne "BOD") { $level = "SALES_MANAGER" }; $reasons += "Tồn kho không đủ đáp ứng toàn bộ" }
    if ($deadlineDays -and $deadlineDays -lt $maxLead) { if ($level -ne "BOD") { $level = "SALES_MANAGER" }; $reasons += "Thời hạn khách yêu cầu ($deadlineDays ngày) < SLA ($maxLead ngày)" }

    # Classification
    if ($missingFields.Count -gt 0 -and ($items.Count -eq 0 -or ($items | Where-Object { $null -eq $_.quantity }))) {
        $status = "NEEDS_INFO"
        $basis = "Thiếu thông tin cốt lõi để tính giá: " + ($missingFields -join ", ")
    } elseif ($deadlineDays -and $deadlineDays -le 1 -and $maxLead -gt 1) {
        $status = "CANNOT_FULFILL"
        $basis = "Thời hạn giao hàng 24h không thể đáp ứng quy chuẩn kỹ thuật SLA ($maxLead ngày)"
    } elseif ($level -ne "SALES_REP") {
        $status = "PENDING_APPROVAL"
        $basis = "Vượt thẩm quyền tự quyết của Sales Rep (" + ($reasons -join "; ") + ")"
    } else {
        $status = "CAN_PROCEED"
        $basis = "Đầy đủ thông tin, hàng sẵn sàng, trong hạn mức tự quyết của Sales Rep"
    }

    # Save to disk
    $dossierText = @"
# HỒ SƠ CƠ HỘI BÁN HÀNG B2B - $oppId
**Khách hàng**: $custName | **Hạng**: $tier
**Đại diện**: $contact | **Email**: $email
**Trạng thái**: $status | **Cấp thẩm quyền**: $level
**Tổng giá trị (Net)**: $([string]::Format('{0:N0}', $netTotal)) VNĐ (Chiết khấu: $([string]::Format('{0:N1}', $effectiveDisc))%)
**Căn cứ**: $basis
"@
    $dossierPath = Join-Path $DossiersDir "Dossier_$oppId.md"
    $dossierText | Out-File -FilePath $dossierPath -Encoding UTF8

    $emailText = @"
TO: $email ($contact)
SUBJECT: [Minh An Technology] Phản hồi cơ hội kinh doanh $oppId - $custName
======================================================================
Trạng thái: $status
Tổng tiền: $([string]::Format('{0:N0}', $netTotal)) VNĐ
Lead time: $maxLead ngày
"@
    $emailPath = Join-Path $DraftEmailsDir "Email_$oppId.txt"
    $emailText | Out-File -FilePath $emailPath -Encoding UTF8

    if ($status -eq "PENDING_APPROVAL") {
        $ticketText = @"
# PHIẾU CHUYỂN DUYỆT CƠ HỘI $oppId
**Kính gửi**: $level | **Khách hàng**: $custName
**Giá trị đơn hàng**: $([string]::Format('{0:N0}', $netTotal)) VNĐ
**Lý do**:
$(($reasons | ForEach-Object { "- 🔴 $_" }) -join "`n")
"@
        $ticketPath = Join-Path $ApprovalTicketsDir "Ticket_TICKET-$oppId.md"
        $ticketText | Out-File -FilePath $ticketPath -Encoding UTF8
    }

    # Append to audit
    $ts = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss.fff")
    Add-Content -Path $AuditLogFile -Value "[$ts] [$reqId] EVENT=LIVE_PROCESSED | STATUS=$status | NET=$netTotal | LEVEL=$level | CUST=$custName" -Encoding UTF8

    return @{
        opp_id = $oppId
        status = $status
        net_total = $netTotal
        discount_pct = $effectiveDisc
        approval_level = $level
        lead_time_days = $maxLead
        basis = $basis
        escalation_reasons = $reasons
        missing_fields = $missingFields
    }
}

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $req = $context.Request
        $urlPath = $req.Url.AbsolutePath

        if ($req.HttpMethod -eq "OPTIONS") {
            Send-Response $context "" "text/plain" 200
            continue
        }

        if ($urlPath -eq "/" -or $urlPath -eq "/index.html") {
            $htmlFile = Join-Path $WebDir "index.html"
            $html = Get-Content $htmlFile -Raw -Encoding UTF8
            Send-Response $context $html "text/html; charset=utf-8"
        }
        elseif ($urlPath -eq "/api/data") {
            $dashJson = if (Test-Path $DashboardPath) { Get-Content $DashboardPath -Raw -Encoding UTF8 | ConvertFrom-Json } else { @{} }
            $sampleReqs = if (Test-Path $SampleRequestsPath) { Get-Content $SampleRequestsPath -Raw -Encoding UTF8 | ConvertFrom-Json } else { @() }
            
            # Map status and totals
            $mapped = @()
            foreach ($s in $sampleReqs) {
                $oppId = $s.id.Replace("REQ-", "OPP-")
                $dossierFile = Join-Path $DossiersDir "Dossier_$oppId.md"
                $status = "CAN_PROCEED"
                $netVal = 0
                $level = "SALES_REP"
                if (Test-Path $dossierFile) {
                    $dContent = Get-Content $dossierFile -Raw -Encoding UTF8
                    if ($dContent -match "(?i)\*\*Trạng thái\*\*:\s*([A-Z_]+)") { $status = $matches[1] }
                    if ($dContent -match "(?i)\*\*Cấp thẩm quyền\*\*:\s*([A-Z_]+)") { $level = $matches[1] }
                    if ($dContent -match "(?i)Tổng giá trị thanh toán \(Net\)\*\*:\s*([\d\.,]+)") {
                        $netVal = [double]($matches[1].Replace(".", "").Replace(",", ""))
                    }
                }
                $mapped += [PSCustomObject]@{
                    id = $s.id
                    customer_name = $s.customer_name
                    contact_person = $s.contact_person
                    status = $status
                    net_total = $netVal
                    approval_level = $level
                }
            }

            $responseObj = @{
                dashboard = $dashJson
                requests = $mapped
            }
            $jsonStr = $responseObj | ConvertTo-Json -Depth 5
            Send-Response $context $jsonStr "application/json; charset=utf-8"
        }
        elseif ($urlPath -eq "/api/audit") {
            $auditText = if (Test-Path $AuditLogFile) { Get-Content $AuditLogFile -Raw -Encoding UTF8 } else { "Chưa có log." }
            Send-Response $context $auditText "text/plain; charset=utf-8"
        }
        elseif ($urlPath -eq "/api/doc") {
            $type = $req.QueryString["type"]
            $id = $req.QueryString["id"]
            $docContent = "Không tìm thấy tài liệu."
            if ($type -eq "dossier") {
                $f = Join-Path $DossiersDir "Dossier_$id.md"
                if (Test-Path $f) { $docContent = Get-Content $f -Raw -Encoding UTF8 }
            } elseif ($type -eq "email") {
                $f = Join-Path $DraftEmailsDir "Email_$id.txt"
                if (Test-Path $f) { $docContent = Get-Content $f -Raw -Encoding UTF8 }
            } elseif ($type -eq "ticket") {
                $f = Join-Path $ApprovalTicketsDir "Ticket_TICKET-$id.md"
                if (Test-Path $f) { $docContent = Get-Content $f -Raw -Encoding UTF8 }
            }
            Send-Response $context $docContent "text/plain; charset=utf-8"
        }
        elseif ($urlPath -eq "/api/process" -and $req.HttpMethod -eq "POST") {
            $reader = New-Object System.IO.StreamReader($req.InputStream, [System.Text.Encoding]::UTF8)
            $body = $reader.ReadToEnd()
            $reader.Close()
            $bodyJson = $body | ConvertFrom-Json
            $result = Run-Agent-Single -reqJson $bodyJson
            $resultStr = $result | ConvertTo-Json -Depth 5
            Send-Response $context $resultStr "application/json; charset=utf-8"
        }
        else {
            Send-Response $context "Not Found" "text/plain" 404
        }
    } catch {
        Write-Host "Lỗi xử lý request: $($_.Exception.Message)" -ForegroundColor Red
    }
}

